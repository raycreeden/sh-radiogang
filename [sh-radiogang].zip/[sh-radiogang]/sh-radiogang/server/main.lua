local QBCore = exports['qb-core']:GetCoreObject()
local freqMembers = {}

-- 🎙️ Unirse a una frecuencia (NO CAMBIAR ESTA PARTE)
RegisterNetEvent("sh-radiogang:joinFreq")
AddEventHandler("sh-radiogang:joinFreq", function(freqId, label, firstname, lastname, grade, playerGang)
    local src = source

    -- Eliminar al jugador de todas las frecuencias anteriores
    for f, t in pairs(freqMembers) do
        if t.members[src] then
            t.members[src] = nil
            t.names[src] = nil
        end
    end

    -- Crear frecuencia si no existe
    if not freqMembers[freqId] then
        freqMembers[freqId] = { members = {}, names = {}, label = label, gang = playerGang }
    end

    -- Agregar jugador a la nueva frecuencia
    freqMembers[freqId].members[src] = true
    freqMembers[freqId].names[src] = firstname .. " " .. lastname .. " [" .. grade .. "]"
    freqMembers[freqId].gang = playerGang

    -- Refrescar todos con todas las frecuencias actualizadas
    TriggerEvent("sh-radiogang:refreshSession")
end)

-- 🔁 Refrescar a todos los jugadores con TODAS las frecuencias activas (CAMBIAR ESTA PARTE)
RegisterNetEvent("sh-radiogang:refreshSession")
AddEventHandler("sh-radiogang:refreshSession", function()
    local allLists = {}

    for freqId, freq in pairs(freqMembers) do
        local list = {}
        for _, name in pairs(freq.names) do
            table.insert(list, name)
        end
        
        -- ✅ CREAR CLAVE ÚNICA: gang + label (ej: "ballas_Frecuencia A")
        local uniqueKey = freq.gang .. "_" .. freq.label
        allLists[uniqueKey] = {
            members = list,
            gang = freq.gang,
            label = freq.label,
            freqId = freqId
        }
    end

    for _, playerId in ipairs(GetPlayers()) do
        local Player = QBCore.Functions.GetPlayer(tonumber(playerId))
        if Player then
            local playerGang = Player.PlayerData.gang.name
            local filteredLists = {}
            
            -- Filtrar solo las frecuencias de la gang del jugador
            for uniqueKey, freqData in pairs(allLists) do
                if freqData.gang == playerGang then
                    filteredLists[freqData.label] = freqData.members
                end
            end
            
            TriggerClientEvent("sh-radiogang:updateMemberList", tonumber(playerId), filteredLists)
        end
    end
end)

-- 🧹 Al desconectarse, eliminarlo de las listas y actualizar a todos
AddEventHandler("playerDropped", function()
    local src = source

    for _, freq in pairs(freqMembers) do
        freq.members[src] = nil
        freq.names[src] = nil
    end

    TriggerEvent("sh-radiogang:refreshSession")
end)

-- 🔌 Desconectarse de todas las frecuencias
RegisterNetEvent("sh-radiogang:leaveAll")
AddEventHandler("sh-radiogang:leaveAll", function()
    local src = source

    for _, freq in pairs(freqMembers) do
        freq.members[src] = nil
        freq.names[src] = nil
    end

    -- 🔄 Actualizar lista para todos
    TriggerEvent("sh-radiogang:refreshSession")
end)

-- Callback para obtener miembros de la gang
QBCore.Functions.CreateCallback('sh-radiogang:server:GetEmployees', function(source, cb, gangname)
    local employees = {}

    -- 🔹 Online players
    for _, id in pairs(QBCore.Functions.GetPlayers()) do
        local Target = QBCore.Functions.GetPlayer(id)
        if Target and Target.PlayerData.gang.name == gangname then
            employees[#employees+1] = {
                cid = Target.PlayerData.citizenid,
                name = "🟢 " .. Target.PlayerData.charinfo.firstname .. " " .. Target.PlayerData.charinfo.lastname,
                grade = Target.PlayerData.gang.grade.name,
                level = Target.PlayerData.gang.grade.level,
                online = true
            }
        end
    end

    -- 🔹 Offline players (leer SQL directamente)
    local result = exports.oxmysql:query_async("SELECT citizenid, charinfo, gang FROM players", {})
    if result then
        for _, row in pairs(result) do
            local ok, gangData = pcall(function() return json.decode(row.gang) end)
            if ok and gangData and gangData.name == gangname then
                local ok2, charinfo = pcall(function() return json.decode(row.charinfo) end)
                local fullName = ok2 and (charinfo.firstname .. " " .. charinfo.lastname) or row.citizenid

                -- si ya está en online, lo saltamos (para no duplicar)
                local alreadyAdded = false
                for _, e in pairs(employees) do
                    if e.cid == row.citizenid then alreadyAdded = true break end
                end
                if not alreadyAdded then
                    employees[#employees+1] = {
                        cid = row.citizenid,
                        name = "🔴" .. fullName,
                        grade = gangData.grade and gangData.grade.name or "Rango 0",
                        level = gangData.grade and gangData.grade.level or 0,
                        online = false
                    }
                end
            end
        end
    end

    cb(employees)
end)

-- Evento para abrir el almacén de jefe
RegisterNetEvent('sh-radiogang:server:OpenStash', function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end
    local playerGang = Player.PlayerData.gang
    
    -- Solo permitir a jefes (nivel 3 o superior)
    if not playerGang.isboss and (not playerGang.grade or playerGang.grade.level < 3) then
        TriggerClientEvent('QBCore:Notify', src, 'No tienes permisos para acceder al almacén de jefe.', 'error')
        return
    end

    local stashName = 'boss_' .. playerGang.name
    exports['qb-inventory']:OpenInventory(src, stashName, {
        maxweight = Config.Stashes.boss.maxweight,
        slots = Config.Stashes.boss.slots,
    })
end)

-- Evento para abrir el almacén común
RegisterNetEvent('sh-radiogang:server:OpenCommonStash', function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end
    local playerGang = Player.PlayerData.gang
    
    -- Verificar que pertenece a una banda
    if playerGang.name == "none" then
        TriggerClientEvent('QBCore:Notify', src, 'No perteneces a ninguna gang.', 'error')
        return
    end

    local stashName = 'gang_' .. playerGang.name .. '_common'
    exports['qb-inventory']:OpenInventory(src, stashName, {
        maxweight = Config.Stashes.common.maxweight,
        slots = Config.Stashes.common.slots,
    })
end)

-- Cambiar grado
RegisterNetEvent('sh-radiogang:server:GradeUpdate', function(data)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player or not Player.PlayerData.gang.isboss then return end

    local Employee = QBCore.Functions.GetPlayerByCitizenId(data.cid) or QBCore.Functions.GetOfflinePlayerByCitizenId(data.cid)
    if Employee then
        if Employee.Functions.SetGang(Player.PlayerData.gang.name, data.grade) then
            Employee.Functions.Save()
            TriggerClientEvent('QBCore:Notify', src, 'Promocionado con éxito!', 'success')
            if Employee.PlayerData and Employee.PlayerData.source then
                TriggerClientEvent('QBCore:Notify', Employee.PlayerData.source, 'Has sido promocionado a ' .. data.gradename, 'success')
            end
        end
    else
        -- Actualizar directamente en la base de datos para jugadores offline
        local gangData = {
            name = Player.PlayerData.gang.name,
            label = Player.PlayerData.gang.label,
            grade = {
                name = data.gradename,
                level = data.grade
            },
            isboss = false
        }
        
        exports.oxmysql:update('UPDATE players SET gang = ? WHERE citizenid = ?', {json.encode(gangData), data.cid})
        TriggerClientEvent('QBCore:Notify', src, 'Promocionado con éxito!', 'success')
    end
end)

-- Expulsar miembro
RegisterNetEvent('sh-radiogang:server:FireMember', function(cid)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player or not Player.PlayerData.gang.isboss then return end

    local Target = QBCore.Functions.GetPlayerByCitizenId(cid) or QBCore.Functions.GetOfflinePlayerByCitizenId(cid)
    if Target then
        if Target.Functions.SetGang("none", 0) then
            Target.Functions.Save()
            TriggerClientEvent('QBCore:Notify', src, 'Miembro expulsado!', 'success')
            if Target.PlayerData and Target.PlayerData.source then
                TriggerClientEvent('QBCore:Notify', Target.PlayerData.source, 'Has sido expulsado de la gang!', 'error')
            end
        end
    else
        -- Actualizar directamente en la base de datos para jugadores offline
        local gangData = {
            name = "none",
            label = "No Gang",
            grade = {
                name = "Sin rango",
                level = 0
            },
            isboss = false
        }
        
        exports.oxmysql:update('UPDATE players SET gang = ? WHERE citizenid = ?', {json.encode(gangData), cid})
        TriggerClientEvent('QBCore:Notify', src, 'Miembro expulsado!', 'success')
    end
end)

-- Contratar miembro
RegisterNetEvent('sh-radiogang:server:HireMember', function(recruit)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    local Target = QBCore.Functions.GetPlayer(recruit)

    if not Player.PlayerData.gang.isboss then
        -- ExploitBan(src, 'HireEmployee Exploiting')
        return
    end

    if Target and Target.Functions.SetGang(Player.PlayerData.gang.name, 0) then
        TriggerClientEvent('QBCore:Notify', src, 'Has contratado a ' .. (Target.PlayerData.charinfo.firstname .. ' ' .. Target.PlayerData.charinfo.lastname) .. ' para ' .. Player.PlayerData.gang.label .. '', 'success')
        TriggerClientEvent('QBCore:Notify', Target.PlayerData.source, 'Has sido contratado como ' .. Player.PlayerData.gang.label .. '', 'success')
        TriggerEvent('qb-log:server:CreateLog', 'gangmenu', 'Recruit', 'yellow', (Player.PlayerData.charinfo.firstname .. ' ' .. Player.PlayerData.charinfo.lastname) .. ' contrató a ' .. Target.PlayerData.charinfo.firstname .. ' ' .. Target.PlayerData.charinfo.lastname .. ' (' .. Player.PlayerData.gang.name .. ')', false)
    end
end)

-- Callback para obtener jugadores cercanos
QBCore.Functions.CreateCallback('sh-radiogang:getplayers', function(source, cb)
    local src = source
    local players = {}
    local PlayerPed = GetPlayerPed(src)
    local pCoords = GetEntityCoords(PlayerPed)
    for _, v in pairs(QBCore.Functions.GetPlayers()) do
        local targetped = GetPlayerPed(v)
        local tCoords = GetEntityCoords(targetped)
        local dist = #(pCoords - tCoords)
        if PlayerPed ~= targetped and dist < 10 then
            local ped = QBCore.Functions.GetPlayer(v)
            players[#players + 1] = {
                id = v,
                coords = GetEntityCoords(targetped),
                name = ped.PlayerData.charinfo.firstname .. ' ' .. ped.PlayerData.charinfo.lastname,
                citizenid = ped.PlayerData.citizenid,
                sources = GetPlayerPed(ped.PlayerData.source),
                sourceplayer = ped.PlayerData.source
            }
        end
    end
    table.sort(players, function(a, b)
        return a.name < b.name
    end)
    cb(players)
end)