// script.js - sh-radiogang

let currentFrequency = null;
let currentReferenceColor = 0; // ← AGREGAR ESTA LÍNEA AQUÍ

window.addEventListener("message", (event) => {
    if (!event || !event.data) return;

    const { action } = event.data;

    if (action === "open") {
        const container = document.getElementById("radioContainer");
        const channelsDiv = document.getElementById("channels");

        container.style.display = "block";
        channelsDiv.innerHTML = "";

        if (event.data.currentFrequency !== undefined) {
            currentFrequency = event.data.currentFrequency;
        }

        if (event.data.onDuty && event.data.categories) {
            event.data.categories.forEach(cat => {
                const catDiv = document.createElement("div");
                catDiv.className = "category";
                catDiv.textContent = cat.name;
                channelsDiv.appendChild(catDiv);

                cat.channels.forEach(ch => {
                    const cont = document.createElement("div");
                    cont.className = "channel-container";
                    cont.dataset.freqid = ch.freqId;
                    cont.dataset.label = ch.label;

                    const btn = document.createElement("button");
                    btn.className = "channelButton";
                    btn.textContent = ch.label;
                    btn.onclick = () => {
                        fetch(`https://${GetParentResourceName()}/joinFreq`, {
                            method: "POST",
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify({ freq: ch.freqId, label: ch.label })
                        });
                        currentFrequency = ch;
                    };

                    const membersDiv = document.createElement("div");
                    membersDiv.className = "channel-members";

                    cont.appendChild(btn);
                    cont.appendChild(membersDiv);
                    channelsDiv.appendChild(cont);
                });
            });
        }
    }

    if (action === "updateMemberList") {
        if (event.data.memberLists && typeof event.data.memberLists === "object") {
            Object.entries(event.data.memberLists).forEach(([freqLabel, members]) => {
                const container = document.querySelector(`.channel-container[data-label="${freqLabel}"]`);
                if (container) {
                    const membersDiv = container.querySelector(".channel-members");
                    if (membersDiv) {
                        membersDiv.innerHTML = "";
                        members.forEach(name => {
                            const div = document.createElement("div");
                            div.className = "member-entry";
                            div.textContent = name;
                            membersDiv.appendChild(div);
                        });
                    }
                }
            });
        }
    }

    if (action === "closeAll") {
        document.getElementById("radioContainer").style.display = "none";
    }
});

// Botón cerrar
document.getElementById("closeBtn").onclick = () => {
    document.getElementById("radioContainer").style.display = "none";
    fetch(`https://${GetParentResourceName()}/close`, { method: "POST" });
};

// Botón Desconectar todas las frecuencias
document.getElementById("disconnectAllBtn").onclick = () => {
    fetch(`https://${GetParentResourceName()}/leaveAllFrequencies`, {
        method: "POST"
    });
};

// Cambiar a pestaña de Frecuencias
document.getElementById("tab-frequencies").onclick = () => showPanel("frequencies-panel");

// Cambiar a pestaña de Interacción
document.getElementById("tab-interact").onclick = () => showPanel("interact-panel");

// Cambiar a pestaña de Objetos
document.getElementById("tab-object").onclick = () => {showPanel("object-panel"); setupObjectButtons(); }; // ⬅️ Renderiza botones de Objetos

document.getElementById("tab-references").onclick = () => {
    showPanel("references-panel"); 
    setupReferencesButtons();
};

// Mostrar el panel correspondiente
function showPanel(panelId) {
    const panels = [
        "frequencies-panel",
        "interact-panel",
        "object-panel",
        "references-panel"
    ];
    panels.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.style.display = (id === panelId) ? "block" : "none";
    });

    const tabs = [
        "tab-frequencies",
        "tab-interact",
        "tab-object",
        "tab-references"
    ];
    tabs.forEach(tabId => {
        const btn = document.getElementById(tabId);
        if (btn) btn.classList.toggle("active", tabId === "tab-" + panelId.split("-")[0]);
    });
}

// Botones de interacción
function setupInteractionButtons() {
    const interactionContainer = document.querySelector(".interaction-buttons");
    if (!interactionContainer) return;
    
    interactionContainer.innerHTML = "";

    const interactions = [
        { id: "cargar", text: "Cargar Persona", icon: "" },
        { id: "meter", text: "Meter en Vehículo", icon: "" },
        { id: "sacar", text: "Sacar del Vehículo", icon: "" },
        { id: "esposar", text: "Esposar/Desesposar", icon: "" },
        { id: "bolsa", text: "Poner/Quitar Bolsa", icon: "" }

    ];

    interactions.forEach(interaction => {
        const button = document.createElement("button");
        button.id = `interact-${interaction.id}`;
        button.innerHTML = `${interaction.icon} ${interaction.text}`;
        button.onclick = () => executeInteraction(interaction.id);
        interactionContainer.appendChild(button);
    });
}

// Ejecutar interacción usando eventos nativos de FiveM
function executeInteraction(action) {
    console.log(`Ejecutando interacción: ${action}`);
    
    // Método simple: enviar evento directamente a FiveM
    fetch(`https://${GetParentResourceName()}/executeInteraction`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: action })
    }).catch(e => {
        console.log("Interacción enviada:", action);
    });
}

// Inicializar botones al cargar
document.addEventListener("DOMContentLoaded", function() {
    setTimeout(setupInteractionButtons, 100);
});

// También inicializar cuando se abre el NUI
window.addEventListener("message", function(event) {
    if (event.data && event.data.action === "open") {
        setTimeout(setupInteractionButtons, 100);
    }
});

// =======================
// Panel Objetos - VERSIÓN CORREGIDA
// =======================

function setupObjectButtons() {
    const container = document.querySelector(".object-buttons");
    if (!container) return;
    container.innerHTML = "";

    const btn = document.createElement("button");
    btn.id = "invoke-jammer";
    btn.innerText = "Desplegar Dispositivo (usar carga)";
    btn.onclick = () => {
        fetch(`https://${GetParentResourceName()}/invokeJammer`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({})
        });
    };

    container.appendChild(btn);

    // estado de cargas por gang
    const status = document.createElement("div");
    status.id = "gang-charges-status";
    status.style.marginTop = "8px";
    status.style.color = "white";
    status.style.fontWeight = "bold";
    status.style.fontSize = "14px";
    status.innerText = "Cargas: 0/10"; // Valor por defecto
    container.appendChild(status);
    
    // SOLUCIÓN: Solicitar cargas actuales
    fetch(`https://${GetParentResourceName()}/getCharges`, {
        method: "POST",
        headers: { "Content-Type": "application/json" }
    }).catch(err => console.log("Error solicitando cargas:", err));
}

// AGREGAR ESTE MANEJADOR DE MENSAJES NUI (ES LO MÁS IMPORTANTE)
window.addEventListener("message", (event) => {
    if (!event || !event.data) return;

    const { type, action } = event.data;

    // Manejar mensajes de actualización de cargas
    if (type === "updateChargesUI") {
        const el = document.getElementById("gang-charges-status");
        if (el) {
            el.innerText = `Cargas: ${event.data.count}/${event.data.max}`;
            console.log(`[UI] Cargas actualizadas: ${event.data.count}/${event.data.max}`);
        }
        return;
    }

    // Mantener el resto del código original para otras acciones...
    if (action === "open") {
        const container = document.getElementById("radioContainer");
        const channelsDiv = document.getElementById("channels");

        container.style.display = "block";
        channelsDiv.innerHTML = "";

        if (event.data.currentFrequency !== undefined) {
            currentFrequency = event.data.currentFrequency;
        }

        if (event.data.onDuty && event.data.categories) {
            event.data.categories.forEach(cat => {
                const catDiv = document.createElement("div");
                catDiv.className = "category";
                catDiv.textContent = cat.name;
                channelsDiv.appendChild(catDiv);

                cat.channels.forEach(ch => {
                    const cont = document.createElement("div");
                    cont.className = "channel-container";
                    cont.dataset.freqid = ch.freqId;
                    cont.dataset.label = ch.label;

                    const btn = document.createElement("button");
                    btn.className = "channelButton";
                    btn.textContent = ch.label;
                    btn.onclick = () => {
                        fetch(`https://${GetParentResourceName()}/joinFreq`, {
                            method: "POST",
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify({ freq: ch.freqId, label: ch.label })
                        });
                        currentFrequency = ch;
                    };

                    const membersDiv = document.createElement("div");
                    membersDiv.className = "channel-members";

                    cont.appendChild(btn);
                    cont.appendChild(membersDiv);
                    channelsDiv.appendChild(cont);
                });
            });
        }

        // Solicitar cargas actualizadas al abrir el NUI
        setTimeout(() => {
            fetch(`https://${GetParentResourceName()}/getCharges`, {
                method: "POST",
                headers: { "Content-Type": "application/json" }
            });
        }, 100);
    }

    if (action === "updateMemberList") {
        if (event.data.memberLists && typeof event.data.memberLists === "object") {
            Object.entries(event.data.memberLists).forEach(([freqLabel, members]) => {
                const container = document.querySelector(`.channel-container[data-label="${freqLabel}"]`);
                if (container) {
                    const membersDiv = container.querySelector(".channel-members");
                    if (membersDiv) {
                        membersDiv.innerHTML = "";
                        members.forEach(name => {
                            const div = document.createElement("div");
                            div.className = "member-entry";
                            div.textContent = name;
                            membersDiv.appendChild(div);
                        });
                    }
                }
            });
        }
    }

    if (action === "closeAll") {
        document.getElementById("radioContainer").style.display = "none";
    }
});

// =======================
// Panel Referencias - SISTEMA AUTOMÁTICO
// =======================

function setupReferencesButtons() {
    const container = document.querySelector(".references-buttons");
    if (!container) return;
    container.innerHTML = "";

    // Crear contenedor principal
    const referencesContent = document.createElement("div");
    referencesContent.innerHTML = `
        
        <div style="margin-bottom: 15px;">
            <h3 style="color: white; margin-bottom: 10px; text-align: center;">Iconos de Referencia</h3>
            <div class="reference-icons">
                <button data-icon="143">Miembro</button>
                <button data-icon="52">Robo Tienda</button>
                <button data-icon="110">Tiroteo</button>
                <button data-icon="496">Venta</button>
                <button data-icon="188">Secuestro</button>
                <button data-icon="455">Yate</button>
                <button data-icon="523">Auto Deportivo</button>
                <button data-icon="545">Carrera</button>
                <button data-icon="674">Relevante</button>
                <button data-icon="617">Joyeria</button>
                <button data-icon="502">1</button>
                <button data-icon="503">2</button>
                <button data-icon="504">3</button>
                <button data-icon="374">Banco</button>
                <button data-icon="72">Grafitis</button>
                <button data-icon="679">Casino</button>
            </div>
        </div>
        <hr style="border-color: #555; margin: 15px 0;">
        <div>
            <h3 style="color: white; margin-bottom: 10px; text-align: center;">Colores</h3>
            <div class="reference-colors">
                <button data-color="0" style="background:#FFFFFF;"></button>
                <button data-color="1" style="background:#ff0000;"></button>
                <button data-color="2" style="background:#10ff03;"></button>
                <button data-color="3" style="background:#0307ff;"></button>
                <button data-color="5" style="background:#fffb03;"></button>
                <button data-color="7" style="background:#8903ff;"></button>
                <button data-color="11" style="background:#87ff81;"></button>
                <button data-color="17" style="background:#ffb803;"></button>
                <button data-color="23" style="background:#ff96fd;"></button>
                <button data-color="28" style="background:#898b00;"></button>
                <button data-color="29" style="background:#030064;"></button>
                <button data-color="40" style="background:#393939;"></button>
            </div>
        </div>
    `;

    container.appendChild(referencesContent);

    // Eventos para iconos
    document.querySelectorAll(".reference-icons button").forEach(button => {
        button.addEventListener("click", () => {
            const iconId = parseInt(button.dataset.icon);
            fetch(`https://${GetParentResourceName()}/setGangReference`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ 
                    icon: iconId, 
                    color: currentReferenceColor 
                })
            });
        });
    });

    // Eventos para colores
    document.querySelectorAll(".reference-colors button").forEach(btn => {
        btn.addEventListener("click", () => {
            currentReferenceColor = parseInt(btn.dataset.color);
        });
    });
}

// Actualizar la función del tab references
document.getElementById("tab-references").onclick = () => {
    showPanel("references-panel"); 
    setupReferencesButtons();
};