local QBCore = exports['qb-core']:GetCoreObject()

-- Blips compartidos por gang
local sharedBlips = {}
local mainBlip = nil
local personalBlipSettings = { icon = 143, color = 0 }
local currentGang = nil
local updateThread = nil
local debugMode = false -- Cambiar a false cuando funcione


-- Función de debug
local function DebugPrint(message)
    if debugMode then
        print("^3[Gang References DEBUG]^0 " .. message)
    end
end

-- Verificar si el jugador está en una gang
local function IsGangMember()
    local PlayerData = QBCore.Functions.GetPlayerData()
    currentGang = PlayerData.gang and PlayerData.gang.name or nil

    if currentGang and currentGang ~= "none" then
        return true
    end

    -- 🚨 Si quieres que arranque incluso si no tienes gang en la DB:
    -- currentGang = "testgang"
    -- return true

    return false
end


-- Iniciar sistema automáticamente
local function StartReferenceSystem()
    if not IsGangMember() then 
        DebugPrint("No se puede iniciar - No es miembro de gang")
        return 
    end
    
    DebugPrint("Iniciando sistema para gang: " .. currentGang)
    
    -- Obtener blip principal
    if not mainBlip then
        mainBlip = GetMainPlayerBlipId()
        DebugPrint("Blip principal obtenido: " .. tostring(mainBlip))
    end
    
    -- Ocultar blip principal
    if DoesBlipExist(mainBlip) then
        SetBlipAlpha(mainBlip, 0)
        DebugPrint("Blip principal ocultado")
    else
        DebugPrint("ERROR: Blip principal no existe")
    end
    
    -- Enviar primer blip al servidor
    DebugPrint("Enviando primer blip al servidor - Icono: " .. personalBlipSettings.icon .. " | Color: " .. personalBlipSettings.color)
    TriggerServerEvent("sh-radiogang:setGangBlip", currentGang, personalBlipSettings.icon, personalBlipSettings.color)
    TriggerServerEvent("sh-radiogang:requestGangBlips", currentGang)
    
    -- Iniciar actualización continua
    if updateThread then
        TerminateThread(updateThread)
        DebugPrint("Thread anterior terminado")
    end
    
    updateThread = CreateThread(function()
        DebugPrint("Thread de actualización iniciado")
        local updateCount = 0
        while currentGang and currentGang ~= "none" do
            updateCount = updateCount + 1
            DebugPrint("Actualización #" .. updateCount .. " enviada")
            TriggerServerEvent("sh-radiogang:setGangBlip", currentGang, personalBlipSettings.icon, personalBlipSettings.color)
            Wait(500) -- 10 segundos para no saturar
        end
        DebugPrint("Thread de actualización terminado")
    end)
end

-- Detener sistema
local function StopReferenceSystem()
    DebugPrint("Deteniendo sistema de referencias")
    
    -- Restaurar blip principal
    if DoesBlipExist(mainBlip) then
        SetBlipAlpha(mainBlip, 255)
        DebugPrint("Blip principal restaurado")
    end
    
    -- Limpiar blips de otros miembros
    local blipsRemoved = 0
    for id, data in pairs(sharedBlips) do
        if data.blip and DoesBlipExist(data.blip) then
            RemoveBlip(data.blip)
            blipsRemoved = blipsRemoved + 1
        end
    end
    sharedBlips = {}
    DebugPrint("Blips removidos: " .. blipsRemoved)
    
    -- Limpiar en servidor
    if currentGang then
        TriggerServerEvent("sh-radiogang:clearGangBlip", currentGang)
        DebugPrint("Limpieza enviada al servidor para gang: " .. currentGang)
    end
    
    -- Detener thread
    if updateThread then
        TerminateThread(updateThread)
        updateThread = nil
        DebugPrint("Thread de actualización terminado")
    end
end

-- Verificar gang al iniciar
CreateThread(function()
    DebugPrint("Script cliente iniciado - Esperando 5 segundos...")
    Wait(2000)
    
    local PlayerData = QBCore.Functions.GetPlayerData()
    DebugPrint("Datos del jugador cargados - Gang: " .. tostring(PlayerData.gang and PlayerData.gang.name or "nil"))
    
    if IsGangMember() then
        DebugPrint("Iniciando sistema automáticamente...")
        StartReferenceSystem()
    else
        DebugPrint("Jugador no pertenece a ninguna gang - Sistema no iniciado")
    end
end)

-- Actualizar cuando cambia la gang
RegisterNetEvent('QBCore:Client:OnGangUpdate', function(_, newGang)
    DebugPrint("Evento OnGangUpdate recibido - Nueva gang: " .. tostring(newGang and newGang.name or "nil"))
    
    -- Detener sistema anterior
    StopReferenceSystem()
    
    -- Actualizar gang actual
    currentGang = newGang and newGang.name or nil
    
    -- Iniciar si pertenece a una gang
    if currentGang and currentGang ~= "none" then
        DebugPrint("Gang cambiada - Reiniciando sistema para: " .. currentGang)
        StartReferenceSystem()
    else
        DebugPrint("Gang cambiada a ninguna - Sistema detenido")
    end
end)

-- Recibir blip de otro miembro de la gang
RegisterNetEvent("sh-radiogang:addGangBlip", function(serverId, gang, icon, color, coords)
    DebugPrint("Recibiendo blip - ServerID: " .. serverId .. " | Gang: " .. gang .. " | Icon: " .. icon .. " | Color: " .. color)
    
    if gang ~= currentGang then 
        DebugPrint("Blip ignorado - Gang diferente: " .. gang .. " vs " .. tostring(currentGang))
        return 
    end

    -- Limpiar blip existente
    if sharedBlips[serverId] and sharedBlips[serverId].blip and DoesBlipExist(sharedBlips[serverId].blip) then
        RemoveBlip(sharedBlips[serverId].blip)
        DebugPrint("Blip existente removido: " .. serverId)
    end

    local blip = nil
    local player = GetPlayerFromServerId(serverId)

    -- Crear blip
    if player ~= -1 then
        local ped = GetPlayerPed(player)
        if DoesEntityExist(ped) then
            blip = AddBlipForEntity(ped)
            DebugPrint("Blip creado en entidad: " .. serverId)
        else
            blip = AddBlipForCoord(coords.x, coords.y, coords.z)
            DebugPrint("Blip creado en coordenadas: " .. serverId)
        end
    else
        blip = AddBlipForCoord(coords.x, coords.y, coords.z)
        DebugPrint("Blip creado en coordenadas (jugador no encontrado): " .. serverId)
    end

    -- Configurar blip
    SetBlipSprite(blip, icon)
    SetBlipColour(blip, color)
    SetBlipScale(blip, 0.85)
    ShowHeadingIndicatorOnBlip(blip, true)
    SetBlipCategory(blip, 7)
    SetBlipPriority(blip, 10)
    SetBlipAsShortRange(blip, false)

    -- Guardar referencia
    sharedBlips[serverId] = { blip = blip }
    DebugPrint("Blip guardado en tabla: " .. serverId)
end)

-- Recibir lista de blips activos de la gang
RegisterNetEvent("sh-radiogang:sendAllGangBlips", function(blips)
    local blipCount = 0
    for _ in pairs(blips) do blipCount = blipCount + 1 end
    DebugPrint("Recibiendo lista de blips - Cantidad: " .. blipCount)
    
    for serverId, blipData in pairs(blips) do
        TriggerEvent("sh-radiogang:addGangBlip", serverId, currentGang, blipData.icon, blipData.color, blipData.coords)
    end
end)

-- Actualizar blip personal desde NUI
RegisterNUICallback("setGangReference", function(data, cb)
    DebugPrint("NUICallback recibido - Icono: " .. data.icon .. " | Color: " .. data.color)
    
    if not IsGangMember() then
        DebugPrint("ERROR: NUICallback - No es miembro de gang")
        cb("ok")
        return
    end

    personalBlipSettings.icon = data.icon
    personalBlipSettings.color = data.color
    
    DebugPrint("Actualizando blip personal - Gang: " .. currentGang)
    TriggerServerEvent("sh-radiogang:setGangBlip", currentGang, data.icon, data.color)
    
    cb("ok")
end)

-- Remover blip específico
RegisterNetEvent("sh-radiogang:removeGangBlip", function(serverId)
    DebugPrint("Removiendo blip: " .. serverId)
    if sharedBlips[serverId] and sharedBlips[serverId].blip and DoesBlipExist(sharedBlips[serverId].blip) then
        RemoveBlip(sharedBlips[serverId].blip)
        DebugPrint("Blip removido: " .. serverId)
    end
    sharedBlips[serverId] = nil
end)

-- Limpiar al desconectarse
AddEventHandler('onResourceStop', function(resourceName)
    if (GetCurrentResourceName() == resourceName) then
        DebugPrint("Resource stopped - Limpiando sistema")
        StopReferenceSystem()
    end
end)

-- Comando de debug
RegisterCommand('gangrefdebug', function()
    debugMode = not debugMode
    print("^3[Gang References]^0 Debug mode: " .. tostring(debugMode))
    print("^3[Gang References]^0 Gang actual: " .. tostring(currentGang))
    print("^3[Gang References]^0 Blips en tabla: " .. tostring(#sharedBlips))
end, false)