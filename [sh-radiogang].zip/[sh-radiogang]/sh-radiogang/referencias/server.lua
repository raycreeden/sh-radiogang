local QBCore = exports['qb-core']:GetCoreObject()

local sharedGangBlips = {}
local debugMode = false
local referenceMissionsActive = {} -- [gang] = { owner = src, started = os.time(), ... }

-- Función de debug
local function DebugPrint(message)
    if debugMode then
        print("^3[Gang References SERVER DEBUG]^0 " .. message)
    end
end

-- Registrar blip de gang
RegisterNetEvent("sh-radiogang:setGangBlip", function(gang, icon, color)
    local src = source
    DebugPrint("Evento setGangBlip recibido - Source: " .. src .. " | Gang: " .. gang .. " | Icon: " .. icon .. " | Color: " .. color)
    
    local Player = QBCore.Functions.GetPlayer(src)
    
    -- Verificar que pertenezca a la gang
    if not Player then
        DebugPrint("ERROR: Jugador no encontrado - Source: " .. src)
        return
    end
    
    if not Player.PlayerData.gang then
        DebugPrint("ERROR: Jugador no tiene gang - Source: " .. src)
        return
    end
    
    if Player.PlayerData.gang.name ~= gang then
        DebugPrint("ERROR: Gang no coincide - Esperada: " .. gang .. " | Actual: " .. Player.PlayerData.gang.name)
        return
    end

    local ped = GetPlayerPed(src)
    local coords = GetEntityCoords(ped)

    -- Inicializar tabla de gang si no existe
    if not sharedGangBlips[gang] then
        sharedGangBlips[gang] = {}
        DebugPrint("Nueva gang registrada: " .. gang)
    end

    -- Guardar/actualizar blip
    sharedGangBlips[gang][src] = {
        icon = icon, 
        color = color, 
        coords = coords,
        name = GetPlayerName(src)
    }

    -- Contar miembros activos
    local memberCount = 0
    for _ in pairs(sharedGangBlips[gang]) do memberCount = memberCount + 1 end

    -- Enviar solo a miembros de la misma gang
    local players = QBCore.Functions.GetPlayers()
    local sentTo = 0
    for _, playerId in ipairs(players) do
        local targetPlayer = QBCore.Functions.GetPlayer(playerId)
        if targetPlayer and targetPlayer.PlayerData.gang and targetPlayer.PlayerData.gang.name == gang then
            TriggerClientEvent("sh-radiogang:addGangBlip", playerId, src, gang, icon, color, coords)
            sentTo = sentTo + 1
        end
    end

    DebugPrint("Blip actualizado - Miembros en gang: " .. memberCount .. " | Enviado a: " .. sentTo .. " jugadores")
end)

-- Solicitar blips activos de la gang
RegisterNetEvent("sh-radiogang:requestGangBlips", function(gang)
    local src = source
    DebugPrint("Solicitud de blips recibida - Source: " .. src .. " | Gang: " .. gang)
    
    if sharedGangBlips[gang] then
        local blipCount = 0
        for _ in pairs(sharedGangBlips[gang]) do blipCount = blipCount + 1 end
        DebugPrint("Enviando " .. blipCount .. " blips a " .. GetPlayerName(src))
        TriggerClientEvent("sh-radiogang:sendAllGangBlips", src, sharedGangBlips[gang])
    else
        DebugPrint("ERROR: No hay blips para la gang: " .. gang)
    end
end)

-- Limpiar blip de gang
RegisterNetEvent("sh-radiogang:clearGangBlip", function(gang)
    local src = source
    DebugPrint("Limpieza de blip solicitada - Source: " .. src .. " | Gang: " .. gang)
    
    if sharedGangBlips[gang] then
        sharedGangBlips[gang][src] = nil
        
        -- Notificar a miembros de la gang
        local players = QBCore.Functions.GetPlayers()
        local notified = 0
        for _, playerId in ipairs(players) do
            local Player = QBCore.Functions.GetPlayer(playerId)
            if Player and Player.PlayerData.gang and Player.PlayerData.gang.name == gang then
                TriggerClientEvent("sh-radiogang:removeGangBlip", playerId, src)
                notified = notified + 1
            end
        end
        
        DebugPrint("Blip limpiado - Notificado a: " .. notified .. " jugadores")
    end
end)

-- Limpiar cuando un jugador se desconecta
AddEventHandler('playerDropped', function(reason)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if Player and Player.PlayerData.gang then
        local gang = Player.PlayerData.gang.name
        if sharedGangBlips[gang] then
            sharedGangBlips[gang][src] = nil
            DebugPrint("Jugador desconectado - Gang: " .. gang .. " | Source: " .. src)
        end
    end
end)

-- Comando de debug en servidor
RegisterCommand('gangrefserverdebug', function(source, args)
    debugMode = not debugMode
    print("^3[Gang References SERVER]^0 Debug mode: " .. tostring(debugMode))
    
    local totalGangs = 0
    local totalBlips = 0
    for gangName, members in pairs(sharedGangBlips) do
        totalGangs = totalGangs + 1
        local memberCount = 0
        for _ in pairs(members) do memberCount = memberCount + 1 end
        totalBlips = totalBlips + memberCount
        print("^3[Gang References SERVER]^0 Gang: " .. gangName .. " | Miembros: " .. memberCount)
    end
    print("^3[Gang References SERVER]^0 Total gangs: " .. totalGangs .. " | Total blips: " .. totalBlips)
end, true)

