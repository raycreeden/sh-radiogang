# Qb-core 
#  " Sh-RadioGang " 
 - Sistema Personalizado de Radio Ilegal
  Bueno no hay mucho que decir, maas allá de lo que dije en el video. Saludos.