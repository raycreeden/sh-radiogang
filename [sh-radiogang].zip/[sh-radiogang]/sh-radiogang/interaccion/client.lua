local QBCore = exports['qb-core']:GetCoreObject()

local isCarrying = false
local carryTarget = nil
local isHandcuffed = false
local handcuffProp = nil
local hasBagOnHead = false  -- ✅ FALTABA ESTA VARIABLE
local bagObject = nil
local isBlind = false

-- Función para verificar si es miembro de gang
local function IsGangMember()
    local data = QBCore.Functions.GetPlayerData()
    return data.gang and data.gang.name ~= "none"
end

-- Función para obtener jugador más cercano
local function GetClosestPlayer()
    local ped = PlayerPedId()
    local pCoords = GetEntityCoords(ped)
    local closest, closestDist = nil, 2.0

    for _, id in ipairs(GetActivePlayers()) do
        local tgtPed = GetPlayerPed(id)
        if tgtPed ~= ped then
            local dist = #(pCoords - GetEntityCoords(tgtPed))
            if dist < closestDist then
                closest = GetPlayerServerId(id)
                closestDist = dist
            end
        end
    end

    return closest, closestDist
end

-- Recibir interacciones desde la NUI (script.js)

RegisterNUICallback("executeInteraction", function(data, cb)
    if not data or not data.action then
        cb({ ok = false, error = "Acción inválida" })
        return
    end

    local action = data.action
    local target, dist = GetClosestPlayer()

    if not target or dist > 2.0 then
        QBCore.Functions.Notify("No hay nadie cerca.", "error")
        cb({ ok = false })
        return
    end

    if action == "cargar" then
        TriggerServerEvent("sh-radiogang:interaccion:carryPlayer", target)

    elseif action == "meter" then
        TriggerServerEvent("sh-radiogang:interaccion:putInVehicle", target)

    elseif action == "sacar" then
        TriggerServerEvent("sh-radiogang:interaccion:takeOutVehicle", target)

    elseif action == "esposar" then
        TriggerServerEvent("sh-radiogang:interaccion:cuffPlayer", target)
    
     elseif action == "bolsa" then
       TriggerServerEvent("sh-radiogang:interaccion:toggleBolsaCabeza", target)

    end

    cb({ ok = true })
end)


-- CARRY: Cargar a un jugador
RegisterNetEvent("sh-radiogang:interaccion:toggleCarry")
AddEventHandler("sh-radiogang:interaccion:toggleCarry", function(carrier, target)
    local myId = GetPlayerServerId(PlayerId())
    local ped = PlayerPedId()

    print("[DEBUG] toggleCarry recibido - Mi ID:", myId, "Carrier:", carrier, "Target:", target)

    if myId == carrier then
        if not isCarrying then
            print("[DEBUG] Iniciando carry como carrier")
            RequestAnimDict("missfinale_c2mcs_1")
            while not HasAnimDictLoaded("missfinale_c2mcs_1") do Wait(0) end
            TaskPlayAnim(ped, "missfinale_c2mcs_1", "fin_c2_mcs_1_camman", 8.0, -8.0, -1, 50, 0, false, false, false)

            local tgtPed = GetPlayerPed(GetPlayerFromServerId(target))
            AttachEntityToEntity(tgtPed, ped, 11816, 0.0, 0.0, 0.55, 0.0, 0.0, 360.0, false, false, false, false, 2, true)
        else
            print("[DEBUG] Soltando carry como carrier")
            ClearPedTasks(ped)
            local tgtPed = GetPlayerPed(GetPlayerFromServerId(target))
            DetachEntity(tgtPed, true, false)
        end
    elseif myId == target then
        if not isCarrying then
            print("[DEBUG] Siendo cargado como target")
            RequestAnimDict("nm")
            while not HasAnimDictLoaded("nm") do Wait(0) end
            TaskPlayAnim(ped, "nm", "firemans_carry", 8.0, -8.0, -1, 5, 20, false, false, false)

            local carrierPed = GetPlayerPed(GetPlayerFromServerId(carrier))
            AttachEntityToEntity(ped, carrierPed, 11816, 0.25, 0.09, 0.45, 12.0, 50.0, 0.0, false, false, false, false, 2, true)
            SetEntityCollision(ped, false, true)
        else
            print("[DEBUG] Dejando de ser cargado como target")
            ClearPedTasks(ped)
            DetachEntity(ped, true, true)
            SetEntityCollision(ped, true, true)
        end
    end

    isCarrying = not isCarrying
    print("[DEBUG] Estado de carry:", isCarrying)
end)

-- Meter en vehículo
RegisterNetEvent("sh-radiogang:interaccion:putInVehicle")
AddEventHandler("sh-radiogang:interaccion:putInVehicle", function()
    print("[DEBUG] putInVehicle recibido")
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)

    if not isHandcuffed then 
        print("[DEBUG] No está esposado, no se puede meter en vehículo")
        return 
    end

    local veh = GetClosestVehicle(coords, 2.5, 0, 70)
    if not veh or not DoesEntityExist(veh) then
        print("[DEBUG] No hay vehículo cercano")
        return 
    end

    local vehCoords = GetEntityCoords(veh)
    if #(coords - vehCoords) > 2.5 then
        print("[DEBUG] Vehículo demasiado lejos")
        return 
    end

    local maxSeats = GetVehicleModelNumberOfSeats(GetEntityModel(veh))
    for seat = 1, maxSeats - 1 do
        if IsVehicleSeatFree(veh, seat) then
            print("[DEBUG] Metiendo en asiento:", seat)
            TaskWarpPedIntoVehicle(ped, veh, seat)
            return
        end
    end
    
    print("[DEBUG] No hay asientos libres")
end)

-- Sacar del vehículo
RegisterNetEvent("sh-radiogang:interaccion:takeOutVehicle")
AddEventHandler("sh-radiogang:interaccion:takeOutVehicle", function()
    print("[DEBUG] takeOutVehicle recibido")
    local ped = PlayerPedId()

    if not isHandcuffed then 
        print("[DEBUG] No está esposado, no se puede sacar del vehículo")
        return 
    end

    if IsPedInAnyVehicle(ped, false) then
        local veh = GetVehiclePedIsIn(ped, false)
        print("[DEBUG] Sacando del vehículo")
        TaskLeaveVehicle(ped, veh, 16)
        Wait(500)
        ClearPedTasks(ped)
    else
        print("[DEBUG] No está en un vehículo")
    end
end)

-- Esposar
RegisterNetEvent("sh-radiogang:interaccion:toggleCuff")
AddEventHandler("sh-radiogang:interaccion:toggleCuff", function(targetId, isCuffer)
    print("[DEBUG] toggleCuff recibido - TargetID:", targetId, "isCuffer:", isCuffer)
    local ped = PlayerPedId()

    if isCuffer then
        print("[DEBUG] Ejecutando animación de esposar como cuffer")
        local targetPed = GetPlayerPed(GetPlayerFromServerId(targetId))
        if not targetPed then return end

        RequestAnimDict("mp_arrest_paired")
        while not HasAnimDictLoaded("mp_arrest_paired") do Wait(0) end
        TaskPlayAnim(ped, "mp_arrest_paired", "cop_p2_back_right", 3.0, 3.0, 2500, 48, 0, false, false, false)
        Wait(2500)
        ClearPedTasks(ped)
        return
    end

    if isHandcuffed then
        print("[DEBUG] Quitando esposas")
        isHandcuffed = false
        ClearPedTasksImmediately(ped)
        SetEnableHandcuffs(ped, false)
        DisablePlayerFiring(PlayerId(), false)
        SetCurrentPedWeapon(ped, `WEAPON_UNARMED`, true)

        if DoesEntityExist(handcuffProp) then
            DeleteEntity(handcuffProp)
            handcuffProp = nil
        end
        return
    end

    print("[DEBUG] Poniendo esposas")
    ClearPedTasksImmediately(ped)

    RequestAnimDict("mp_arrest_paired")
    while not HasAnimDictLoaded("mp_arrest_paired") do Wait(0) end
    TaskPlayAnim(ped, "mp_arrest_paired", "crook_p2_back_right", 3.0, 3.0, 3000, 32, 0, false, false, false)
    Wait(3000)

    RequestAnimDict("mp_arresting")
    while not HasAnimDictLoaded("mp_arresting") do Wait(0) end
    TaskPlayAnim(ped, "mp_arresting", "idle", 8.0, -8.0, -1, 49, 0, false, false, false)

    SetEnableHandcuffs(ped, true)
    DisablePlayerFiring(PlayerId(), true)
    SetCurrentPedWeapon(ped, `WEAPON_UNARMED`, true)
    isHandcuffed = true

    local model = `p_cs_cuffs_02_s`
    RequestModel(model)
    while not HasModelLoaded(model) do Wait(0) end

    local bone = GetPedBoneIndex(ped, 24818)
    local cuffs = CreateObject(model, GetEntityCoords(ped), true, true, true)
    AttachEntityToEntity(cuffs, ped, bone, -0.26, -0.2, 0.015, -0.0, 90.0, 180.0, true, true, false, true, 3, true)
    handcuffProp = cuffs
end)

-- Bloqueo de controles cuando está esposado
CreateThread(function()
    while true do
        Wait(0)
        if isHandcuffed then
            DisableControlAction(0, 24, true)
            DisableControlAction(0, 25, true)
            DisableControlAction(0, 23, true)
            DisableControlAction(0, 22, true)
            DisableControlAction(0, 21, true)
            DisableControlAction(0, 44, true)
            DisableControlAction(0, 37, true)
        end
    end
end)

-- Poner/Quitar Bolsa
RegisterNetEvent("sh-radiogang:interaccion:colocarBolsaCabeza")
AddEventHandler("sh-radiogang:interaccion:colocarBolsaCabeza", function()
    print("[DEBUG] colocarBolsaCabeza recibido")
    if hasBagOnHead then 
        print("[DEBUG] Ya tiene bolsa en la cabeza")
        return 
    end
    
    local ped = PlayerPedId()

    local model = `prop_cs_sack_01`
    RequestModel(model)
    while not HasModelLoaded(model) do Wait(10) end

    local bone = GetPedBoneIndex(ped, 12844)
    local obj = CreateObject(model, 0.0, 0.0, 0.0, true, true, false)
    AttachEntityToEntity(obj, ped, bone, 0.0, 0.01, 0.0, 90.0, 260.0, 20.0, true, true, false, true, 2, true)
    bagObject = obj

    isBlind = true
    hasBagOnHead = true
    AnimpostfxPlay("MP_race_crash", 100000, true)
    print("[DEBUG] Bolsa colocada")
end)

RegisterNetEvent("sh-radiogang:interaccion:quitarBolsaCabeza")
AddEventHandler("sh-radiogang:interaccion:quitarBolsaCabeza", function()
    print("[DEBUG] quitarBolsaCabeza recibido")
    if DoesEntityExist(bagObject) then
        DeleteEntity(bagObject)
        bagObject = nil
    end
    isBlind = false
    hasBagOnHead = false
    AnimpostfxStop("MP_race_crash")
    print("[DEBUG] Bolsa removida")
end)

-- Pantalla negra mientras tenga la bolsa
CreateThread(function()
    while true do
        if isBlind then
            DrawRect(0.5, 0.5, 1.0, 1.0, 0, 0, 0, 255)
        else
            Wait(500)
        end
        Wait(0)
    end
end)

-- Comando para ejecutar interacciones desde NUI
RegisterCommand("sh_gang_interact", function(source, args)
    print("[DEBUG] Comando sh_gang_interact ejecutado con args:", table.concat(args, " "))
    
    if not IsGangMember() then
        QBCore.Functions.Notify("No perteneces a ninguna gang.", "error")
        return
    end

    local action = args[1]
    local target, dist = GetClosestPlayer()

    if not target or dist > 2.0 then
        QBCore.Functions.Notify("No hay nadie cerca.", "error")
        return
    end

    if action == "cargar" then
        TriggerServerEvent("sh-radiogang:interaccion:carryPlayer", target)
    elseif action == "meter" then
        TriggerServerEvent("sh-radiogang:interaccion:putInVehicle", target)
    elseif action == "sacar" then
        TriggerServerEvent("sh-radiogang:interaccion:takeOutVehicle", target)
    elseif action == "esposar" then
        TriggerServerEvent("sh-radiogang:interaccion:cuffPlayer", target)
    elseif action == "bolsa" then
        TriggerServerEvent("sh-radiogang:interaccion:toggleBolsaCabeza", target)
    else
        QBCore.Functions.Notify("Acción no válida. Usa: cargar, meter, sacar, esposar, bolsa", "error")
    end
end, false)

-- Comando de prueba directo
RegisterCommand("testcuff", function()
    if not IsGangMember() then
        QBCore.Functions.Notify("No perteneces a ninguna gang.", "error")
        return
    end

    local target, dist = GetClosestPlayer()
    if not target or dist > 2.0 then
        QBCore.Functions.Notify("No hay nadie cerca.", "error")
        return
    end

    print("[DEBUG TEST] Enviando evento cuffPlayer para target:", target)
    TriggerServerEvent("sh-radiogang:interaccion:cuffPlayer", target)
end, false)
