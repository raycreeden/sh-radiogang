local QBCore = exports['qb-core']:GetCoreObject()

local handcuffedPlayers = {}
local playersWithBag = {}

-- Verificar si es miembro de gang
local function IsGangMember(playerId)
    local Player = QBCore.Functions.GetPlayer(playerId)
    return Player and Player.PlayerData.gang and Player.PlayerData.gang.name ~= "none"
end

-- Función para obtener jugador más cercano (serverside)
function GetClosestPlayer(source)
    local players = GetPlayers()
    local closestPlayer = nil
    local closestDistance = -1
    local sourceCoords = GetEntityCoords(GetPlayerPed(source))

    for _, player in ipairs(players) do
        local playerId = tonumber(player)
        if playerId ~= source then
            local playerCoords = GetEntityCoords(GetPlayerPed(playerId))
            local distance = #(sourceCoords - playerCoords)

            if closestDistance == -1 or distance < closestDistance then
                closestPlayer = playerId
                closestDistance = distance
            end
        end
    end

    return closestPlayer, closestDistance
end

-- CARRY
RegisterNetEvent("sh-radiogang:interaccion:carryPlayer")
AddEventHandler("sh-radiogang:interaccion:carryPlayer", function(target)
    local src = source
    if not IsGangMember(src) then 
        TriggerClientEvent("QBCore:Notify", src, "No perteneces a ninguna gang", "error")
        return 
    end
    
    TriggerClientEvent("sh-radiogang:interaccion:toggleCarry", src, src, target)
    TriggerClientEvent("sh-radiogang:interaccion:toggleCarry", target, src, target)
end)

-- METER EN VEHÍCULO
RegisterNetEvent("sh-radiogang:interaccion:putInVehicle")
AddEventHandler("sh-radiogang:interaccion:putInVehicle", function(target)
    local src = source
    if not IsGangMember(src) then 
        TriggerClientEvent("QBCore:Notify", src, "No perteneces a ninguna gang", "error")
        return 
    end
    if not handcuffedPlayers[target] then 
        TriggerClientEvent("QBCore:Notify", src, "La persona no está esposada", "error")
        return 
    end
    
    TriggerClientEvent("sh-radiogang:interaccion:putInVehicle", target)
end)

-- SACAR DEL VEHÍCULO
RegisterNetEvent("sh-radiogang:interaccion:takeOutVehicle")
AddEventHandler("sh-radiogang:interaccion:takeOutVehicle", function(target)
    local src = source
    if not IsGangMember(src) then 
        TriggerClientEvent("QBCore:Notify", src, "No perteneces a ninguna gang", "error")
        return 
    end
    if not handcuffedPlayers[target] then 
        TriggerClientEvent("QBCore:Notify", src, "La persona no está esposada", "error")
        return 
    end
    
    TriggerClientEvent("sh-radiogang:interaccion:takeOutVehicle", target)
end)

-- ESPOSAR
RegisterNetEvent("sh-radiogang:interaccion:cuffPlayer")
AddEventHandler("sh-radiogang:interaccion:cuffPlayer", function(targetId)
    local src = source
    if not IsGangMember(src) then 
        TriggerClientEvent("QBCore:Notify", src, "No perteneces a ninguna gang", "error")
        return 
    end
    if not targetId then 
        TriggerClientEvent("QBCore:Notify", src, "No hay nadie cerca", "error")
        return 
    end

    local wasCuffed = handcuffedPlayers[targetId] or false
    handcuffedPlayers[targetId] = not wasCuffed

    -- primero animación en el que esposa
TriggerClientEvent("sh-radiogang:interaccion:toggleCuff", src, targetId, true)

-- luego aplicar/quitar esposas en el target
TriggerClientEvent("sh-radiogang:interaccion:toggleCuff", targetId, src, false)

end)

-- BOLSA
RegisterNetEvent("sh-radiogang:interaccion:toggleBolsaCabeza")
AddEventHandler("sh-radiogang:interaccion:toggleBolsaCabeza", function(target)
    local src = source
    if not IsGangMember(src) then 
        TriggerClientEvent("QBCore:Notify", src, "No perteneces a ninguna gang", "error")
        return 
    end

    if not handcuffedPlayers[target] then
        TriggerClientEvent("QBCore:Notify", src, "La persona no está esposada", "error")
        return
    end

    if playersWithBag[target] then
        TriggerClientEvent("sh-radiogang:interaccion:quitarBolsaCabeza", target)
        playersWithBag[target] = nil
        TriggerClientEvent("QBCore:Notify", src, "Bolsa removida", "primary")
    else
        TriggerClientEvent("sh-radiogang:interaccion:colocarBolsaCabeza", target)
        playersWithBag[target] = true
        TriggerClientEvent("QBCore:Notify", src, "Bolsa colocada", "success")
    end
end)

-- Endpoint simple para HTTP requests (solo para evitar errores)
Citizen.CreateThread(function()
    -- Crear un endpoint HTTP simple que no haga nada pero evite errores
    exports('executeInteraction', function(req, res)
        local data = json.decode(req.body)
        if data and data.action then
            TriggerEvent("sh-radiogang:interaccion:nuiInteract", data.action, source)
            res.send(json.encode({success = true}))
        else
            res.send(json.encode({error = "Acción no válida"}))
        end
    end)
end)

-- Evento para interacciones desde NUI
RegisterServerEvent("sh-radiogang:interaccion:nuiInteract")
AddEventHandler("sh-radiogang:interaccion:nuiInteract", function(action)
    local src = source
    if not IsGangMember(src) then 
        TriggerClientEvent("QBCore:Notify", src, "No perteneces a ninguna gang", "error")
        return 
    end

    local target, dist = GetClosestPlayer(src)
    if not target or dist > 2.0 then
        TriggerClientEvent("QBCore:Notify", src, "No hay nadie cerca", "error")
        return
    end

    if action == "cargar" then
        TriggerEvent("sh-radiogang:interaccion:carryPlayer", target)
    elseif action == "meter" then
        TriggerEvent("sh-radiogang:interaccion:putInVehicle", target)
    elseif action == "sacar" then
        TriggerEvent("sh-radiogang:interaccion:takeOutVehicle", target)
    elseif action == "esposar" then
        TriggerEvent("sh-radiogang:interaccion:cuffPlayer", target)
    elseif action == "bolsa" then
        TriggerEvent("sh-radiogang:interaccion:toggleBolsaCabeza", target)
    end
end)

-- Limpiar estado al desconectarse
AddEventHandler("playerDropped", function()
    local src = source
    handcuffedPlayers[src] = nil
    playersWithBag[src] = nil
end)
