fx_version 'cerulean'
lua54 'yes'
game 'gta5'

author 'SherlockCo'
description 'Radio Gang independiente'
version '1.0.0'

shared_script {
    'config.lua'
}

client_scripts {
    'client/main.lua',
    'interaccion/client.lua',
    'objetos/client.lua',
    'referencias/client.lua'
}

server_scripts {
    'server/main.lua',
    'interaccion/server.lua',
    'objetos/server.lua',
    'referencias/server.lua'
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js'
}

dependencies {
    'pma-voice',
    'qb-core'
}