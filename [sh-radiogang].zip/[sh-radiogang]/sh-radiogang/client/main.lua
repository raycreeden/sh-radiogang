local QBCore = exports['qb-core']:GetCoreObject()
Locales = Locales or {}
Lang = Locales[Config.Locale] or {}

local radioOpen = false
local onDuty = true
local currentSession = nil
local isNuiFocused = false

-- Gang Menu functionality
local inGangMenuZone = false
local shownGangMenu = false
local gangMenuZones = {}
local PlayerGang = QBCore.Functions.GetPlayerData().gang
local DynamicMenuItems = {}

function IsGangMember()
    local playerData = QBCore.Functions.GetPlayerData()
    return playerData.gang and playerData.gang.name ~= "none"
end

function _L(key, vars)
    local str = Lang[key] or ("[" .. key .. "]")
    if vars then
        for k, v in pairs(vars) do
            str = str:gsub("%%{" .. k .. "}", v)
        end
    end
    return str
end

-- Función para configurar qb-target
function SetupGangTargetZones()
    for gangName, locations in pairs(Config.GangMenu.locations) do
        for index, coords in ipairs(locations) do
            local zoneId = gangName .. "_gangmenu_" .. index
            
            exports['qb-target']:AddBoxZone(zoneId, coords, 1.5, 1.5, {
                name = zoneId,
                heading = 0,
                debugPoly = false,
                minZ = coords.z - 1,
                maxZ = coords.z + 1,
            }, {
                options = {
                    {
                        type = "client",
                        event = "sh-radiogang:client:OpenGangMenu",
                        icon = "fas fa-sign-in-alt",
                        label = "Abrir Menú de Gang",
                        gang = gangName,
                        canInteract = function()
                            local playerGang = QBCore.Functions.GetPlayerData().gang
                            return playerGang.name == gangName
                        end,
                    }
                },
                distance = 2.5
            })
            
            gangMenuZones[zoneId] = true
        end
    end
end

RegisterNetEvent('sh-radiogang:client:OpenGangMenu', function(data)
    local PlayerData = QBCore.Functions.GetPlayerData()
    local gangName = PlayerData.gang and PlayerData.gang.name or "none"

    if not data or not data.gang then
        if gangName ~= "none" then
            OpenGangMenu()
        else
            QBCore.Functions.Notify("No perteneces a ninguna gang.", "error")
        end
        return
    end

    if gangName == data.gang then
        OpenGangMenu()
    else
        QBCore.Functions.Notify("No perteneces a esta gang.", "error")
    end
end)


-- Desactivar radio al iniciar
CreateThread(function()
    exports["pma-voice"]:setVoiceProperty("radioEnabled", false)
    exports["pma-voice"]:setRadioChannel(0)
end)

-- Tecla para abrir la radio
CreateThread(function()
    while true do
        Wait(0)
        if IsControlJustReleased(0, Config.OpenKey) then
            OpenRadio()
        end
    end
end)

-- Función para abrir radio Gang
function OpenRadio()
    local PlayerData = QBCore.Functions.GetPlayerData()

    local hasItem = false
    for _, v in pairs(PlayerData.items) do
        if v and v.name == Config.RequiredItem then
            hasItem = true
            break
        end
    end
    if not hasItem then return QBCore.Functions.Notify("Necesitas una radio.", "error") end

    if not IsGangMember() then return QBCore.Functions.Notify("No tienes acceso a esta radio.", "error") end

    onDuty = true
    SetNuiFocusKeepInput(true)
    SetNuiFocus(true, true)
    isNuiFocused = true

    -- Generar categorías basadas en la gang del jugador
    local categories = {}
    local gangName = PlayerData.gang.name
    if Config.GangFrequencies[gangName] then
        local gangFreq = Config.GangFrequencies[gangName]
        local gangChannels = {}
        
        for i = 1, #Config.FrequencyNames do
            table.insert(gangChannels, {
                label = Config.FrequencyNames[i],
                freqId = gangFreq.start + (i - 1)
            })
        end
        
        table.insert(categories, {
            name = "Operaciones Ilegales - " .. gangFreq.name,
            channels = gangChannels
        })
    end

    SendNUIMessage({
        action = "open",
        onDuty = onDuty,
        serviceDuty = true,
        categories = categories,
        currentFrequency = currentSession
    })

    TriggerServerEvent("sh-radiogang:refreshSession")
end

-- Unirse a frecuencia
RegisterNUICallback("joinFreq", function(data, cb)
    local freq = tonumber(data.freq)
    if not freq then return cb("invalid") end

    currentSession = freq
    exports["pma-voice"]:setVoiceProperty("radioEnabled", true)
    exports["pma-voice"]:setRadioChannel(freq)

    local PlayerData = QBCore.Functions.GetPlayerData()
    local firstname = PlayerData.charinfo.firstname
    local lastname = PlayerData.charinfo.lastname
    local grade = PlayerData.gang.grade.name or "Desconocido"
    local playerGang = PlayerData.gang.name

    TriggerServerEvent("sh-radiogang:joinFreq", freq, data.label, firstname, lastname, grade, playerGang)
    cb("ok")
end)

-- Desconectar frecuencia
RegisterNUICallback("disconnectFreq", function(_, cb)
    exports["pma-voice"]:setVoiceProperty("radioEnabled", false)
    exports["pma-voice"]:setRadioChannel(0)
    currentSession = nil
    cb("ok")
end)

-- Cerrar NUI
RegisterNUICallback("close", function(_, cb)
    SetNuiFocus(false, false)
    isNuiFocused = false
    SendNUIMessage({ action = "close" })
    cb("ok")
end)

-- Refrescar manualmente
RegisterNUICallback("refreshFrequencies", function(_, cb)
    TriggerServerEvent("sh-radiogang:refreshSession")
    cb("ok")
end)

-- Salir de todas las frecuencias
RegisterNUICallback("leaveAllFrequencies", function(_, cb)
    exports["pma-voice"]:setVoiceProperty("radioEnabled", false)
    exports["pma-voice"]:setRadioChannel(0)
    currentSession = nil

    QBCore.Functions.Notify("Has salido de todas las frecuencias.", "primary", 3000)
    TriggerServerEvent("sh-radiogang:leaveAll")

    cb("ok")
end)

-- 📡 Recibir todas las frecuencias activas
RegisterNetEvent("sh-radiogang:updateMemberList", function(memberLists)
    SendNUIMessage({
        action = "updateMemberList",
        memberLists = memberLists
    })
end)

-- Bloquear movimiento mientras está abierto el NUI
CreateThread(function()
    while true do
        Wait(0)
        if isNuiFocused then
          DisableControlAction(0, 1, true)
          DisableControlAction(0, 2, true)
          DisableControlAction(0, 24, true)
          DisableControlAction(0, 21, true)
          DisableControlAction(0, 22, true)
          DisableControlAction(0, 44, true)
          DisableControlAction(0, 289, true)
        end
    end
end)

-- Función para abrir el menú de gang
function OpenGangMenu()
    shownGangMenu = true
    local PlayerData = QBCore.Functions.GetPlayerData()
    PlayerGang = PlayerData.gang
    
    local menu = {
        {
            header = "Menú de Gang - " .. PlayerGang.label,
            isMenuHeader = true
        },
        {
            header = "Gestionar Miembros",
            txt = "Ver y gestionar miembros de la gang",
            params = {
                event = "sh-radiogang:client:ManageGang",
            }
        },
        {
            header = "Contratar Miembros",
            txt = "Contratar jugadores cercanos",
            params = {
                event = "sh-radiogang:client:HireMembers",
            }
        },
        {
            header = "Almacén de Jefe",
            txt = "Almacén exclusivo para jefes",
            params = {
                event = "sh-radiogang:client:OpenStash",
            },
            -- Solo visible para jefes (nivel 3 o superior)
            disabled = not (PlayerGang and PlayerGang.grade and PlayerGang.grade.level >= 3)
        },
        {
            header = "Almacén Común",
            txt = "Almacén para todos los miembros",
            params = {
                event = "sh-radiogang:client:OpenCommonStash",
            }
        },
        {
            header = "Ropa",
            txt = "Cambiar outfit",
            params = {
                event = "sh-radiogang:client:Wardrobe",
            }
        },
        
        {
            header = "Cerrar",
            txt = "",
            params = {
                event = "qb-menu:client:closeMenu"
            }
        }
    }
    
    exports['qb-menu']:openMenu(menu)
end

-- Evento para abrir el almacén común
RegisterNetEvent("sh-radiogang:client:OpenCommonStash", function()
    TriggerServerEvent("sh-radiogang:server:OpenCommonStash")
end)

-- Abrir listado de miembros de la gang
RegisterNetEvent("sh-radiogang:client:ManageGang", function()
    local PlayerData = QBCore.Functions.GetPlayerData()
    local PlayerGang = PlayerData.gang

    -- permitir solo rango 2 o más
    if not (PlayerGang and PlayerGang.grade and PlayerGang.grade.level >= 2) then
        QBCore.Functions.Notify("No tienes permisos para gestionar miembros.", "error")
        return
    end

    QBCore.Functions.TriggerCallback('sh-radiogang:server:GetEmployees', function(members)
        if not members or #members == 0 then
            QBCore.Functions.Notify("No se encontraron miembros en tu gang.", "error")
            return
        end

        local menu = {
            { header = "Miembros de " .. (PlayerGang.label or PlayerGang.name), isMenuHeader = true }
        }

        for _, m in ipairs(members) do
            menu[#menu+1] = {
                header = m.name,
                txt = "Rango: " .. (m.grade or "Desconocido"),
                params = {
                    event = "sh-radiogang:client:ManageMember",
                    args = m
                }
            }
        end

        menu[#menu+1] = { header = "Volver", params = { event = "sh-radiogang:client:OpenGangMenu" } }

        exports['qb-menu']:openMenu(menu)
    end, PlayerGang.name)
end)


-- Submenú de gestión de un miembro
RegisterNetEvent("sh-radiogang:client:ManageMember", function(member)
    if not member then
        QBCore.Functions.Notify("Error cargando datos del miembro.", "error")
        return
    end

    local PlayerData = QBCore.Functions.GetPlayerData()
    local PlayerGang = PlayerData.gang
    local gangGrades = QBCore.Shared.Gangs[PlayerGang.name].grades or {}

    local MemberMenu = {
        { header = "Gestionar " .. (member.name or "Desconocido"), isMenuHeader = true }
    }

    -- Opción de cambiar rango
    for gradeId, gradeInfo in pairs(gangGrades) do
        MemberMenu[#MemberMenu+1] = {
            header = "Ascender a " .. gradeInfo.name,
            txt = "Rango " .. gradeId,
            params = {
                isServer = true,
                event = "sh-radiogang:server:GradeUpdate",
                args = { cid = member.cid, grade = tonumber(gradeId), gradename = gradeInfo.name }
            }
        }
    end

    -- Opción de despedir
    MemberMenu[#MemberMenu+1] = {
        header = "Despedir",
        txt = "Expulsar de la gang",
        params = {
            isServer = true,
            event = "sh-radiogang:server:FireMember",
            args = member.cid
        }
    }

    MemberMenu[#MemberMenu+1] = { header = "Volver", params = { event = "sh-radiogang:client:ManageGang" } }

    exports['qb-menu']:openMenu(MemberMenu)
end)


-- Evento para contratar miembros
RegisterNetEvent("sh-radiogang:client:HireMembers", function()
    local HireMembersMenu = {
        {
            header = "Contratar Jugadores",
            isMenuHeader = true,
        },
    }
    QBCore.Functions.TriggerCallback('sh-radiogang:getplayers', function(players)
        for _, v in pairs(players) do
            if v and v ~= PlayerId() then
                HireMembersMenu[#HireMembersMenu + 1] = {
                    header = v.name,
                    txt = "CID: " .. v.citizenid .. " - ID: " .. v.sourceplayer,
                    params = {
                        isServer = true,
                        event = "sh-radiogang:server:HireMember",
                        args = v.sourceplayer
                    }
                }
            end
        end
        HireMembersMenu[#HireMembersMenu + 1] = {
            header = "Volver",
            params = {
                event = "sh-radiogang:client:OpenGangMenu",
            }
        }
        exports['qb-menu']:openMenu(HireMembersMenu)
    end)
end)

-- Evento para abrir el almacén de jefe
RegisterNetEvent("sh-radiogang:client:OpenStash", function()
    local PlayerData = QBCore.Functions.GetPlayerData()
    if PlayerData.gang and PlayerData.gang.grade and PlayerData.gang.grade.level >= 3 then
        TriggerServerEvent("sh-radiogang:server:OpenStash")
    else
        QBCore.Functions.Notify("No tienes permisos para acceder al almacén de jefe.", "error")
    end
end)

-- Evento para el guardarropa
RegisterNetEvent("sh-radiogang:client:Wardrobe", function()
    TriggerEvent('qb-clothing:client:openOutfitMenu')
end)

-- Notificación al expulsarse
RegisterNetEvent("sh-radiogang:client:notify", function(msg, type)
    QBCore.Functions.Notify(msg, type)
end)

-- Función para mostrar notificación de ayuda
function ShowHelpNotification(msg)
    AddTextEntry('HelpNotification', msg)
    BeginTextCommandDisplayHelp('HelpNotification')
    EndTextCommandDisplayHelp(0, false, true, -1)
end

-- Configuración de qb-target o sistema de tecla E
if Config.GangMenu.useTarget then
    -- Configurar qb-target al iniciar el recurso
    CreateThread(function()
        Wait(1000) -- Esperar a que qb-target esté listo
        SetupGangTargetZones()
    end)
else
    -- Mantener el sistema de tecla E
    CreateThread(function()
        while true do
            local wait = 2500
            local player = PlayerPedId()
            local coords = GetEntityCoords(player)
            local playerGang = QBCore.Functions.GetPlayerData().gang.name

            if playerGang and playerGang ~= "none" and Config.GangMenu.locations[playerGang] then
                for _, menuCoords in pairs(Config.GangMenu.locations[playerGang]) do
                    local dist = #(coords - menuCoords)
                    if dist < 5.0 then
                        wait = 0
                        if dist < 1.5 then
                            if not shownGangMenu then
                                ShowHelpNotification(Config.GangMenu.menuText)
                                if IsControlJustReleased(0, Config.GangMenu.menuKey) then
                                    OpenGangMenu()
                                end
                            end
                        else
                            if shownGangMenu then
                                shownGangMenu = false
                            end
                        end
                    end
                end
            end
            Wait(wait)
        end
    end)
end

-- Función para limpiar las zonas de target si es necesario
AddEventHandler('onResourceStop', function(resourceName)
    if GetCurrentResourceName() == resourceName then
        for zoneId, _ in pairs(gangMenuZones) do
            exports['qb-target']:RemoveZone(zoneId)
        end
    end
end)

-- Actualizar la gang cuando cambie
RegisterNetEvent('QBCore:Client:OnGangUpdate', function(InfoGang)
    PlayerGang = InfoGang
end)

local QBCore = exports['qb-core']:GetCoreObject()

local handcuffedPlayers = {}
local playersWithBag = {}

-- Verificar si es miembro de gang
local function IsGangMember(playerId)
    local Player = QBCore.Functions.GetPlayer(playerId)
    return Player and Player.PlayerData.gang and Player.PlayerData.gang.name ~= "none"
end

-- Función para obtener jugador más cercano (serverside)
function GetClosestPlayer(source)
    local players = GetPlayers()
    local closestPlayer = nil
    local closestDistance = -1
    local sourceCoords = GetEntityCoords(GetPlayerPed(source))

    for _, player in ipairs(players) do
        local playerId = tonumber(player)
        if playerId ~= source then
            local playerCoords = GetEntityCoords(GetPlayerPed(playerId))
            local distance = #(sourceCoords - playerCoords)

            if closestDistance == -1 or distance < closestDistance then
                closestPlayer = playerId
                closestDistance = distance
            end
        end
    end

    return closestPlayer, closestDistance
end

-- CARRY
RegisterNetEvent("sh-radiogang:interaccion:carryPlayer")
AddEventHandler("sh-radiogang:interaccion:carryPlayer", function(target)
    local src = source
    if not IsGangMember(src) then 
        TriggerClientEvent("QBCore:Notify", src, "No perteneces a ninguna gang", "error")
        return 
    end
    
    TriggerClientEvent("sh-radiogang:interaccion:toggleCarry", src, src, target)
    TriggerClientEvent("sh-radiogang:interaccion:toggleCarry", target, src, target)
end)

-- METER EN VEHÍCULO
RegisterNetEvent("sh-radiogang:interaccion:putInVehicle")
AddEventHandler("sh-radiogang:interaccion:putInVehicle", function(target)
    local src = source
    if not IsGangMember(src) then 
        TriggerClientEvent("QBCore:Notify", src, "No perteneces a ninguna gang", "error")
        return 
    end
    if not handcuffedPlayers[target] then 
        TriggerClientEvent("QBCore:Notify", src, "La persona no está esposada", "error")
        return 
    end
    
    TriggerClientEvent("sh-radiogang:interaccion:putInVehicle", target)
end)

-- SACAR DEL VEHÍCULO
RegisterNetEvent("sh-radiogang:interaccion:takeOutVehicle")
AddEventHandler("sh-radiogang:interaccion:takeOutVehicle", function(target)
    local src = source
    if not IsGangMember(src) then 
        TriggerClientEvent("QBCore:Notify", src, "No perteneces a ninguna gang", "error")
        return 
    end
    if not handcuffedPlayers[target] then 
        TriggerClientEvent("QBCore:Notify", src, "La persona no está esposada", "error")
        return 
    end
    
    TriggerClientEvent("sh-radiogang:interaccion:takeOutVehicle", target)
end)

-- ESPOSAR
RegisterNetEvent("sh-radiogang:interaccion:cuffPlayer")
AddEventHandler("sh-radiogang:interaccion:cuffPlayer", function(targetId)
    local src = source
    if not IsGangMember(src) then 
        TriggerClientEvent("QBCore:Notify", src, "No perteneces a ninguna gang", "error")
        return 
    end
    if not targetId then 
        TriggerClientEvent("QBCore:Notify", src, "No hay nadie cerca", "error")
        return 
    end

    local wasCuffed = handcuffedPlayers[targetId] or false
    handcuffedPlayers[targetId] = not wasCuffed

    TriggerClientEvent("sh-radiogang:interaccion:toggleCuff", targetId, src, not wasCuffed)
end)

-- BOLSA
RegisterNetEvent("sh-radiogang:interaccion:toggleBolsaCabeza")
AddEventHandler("sh-radiogang:interaccion:toggleBolsaCabeza", function(target)
    local src = source
    if not IsGangMember(src) then 
        TriggerClientEvent("QBCore:Notify", src, "No perteneces a ninguna gang", "error")
        return 
    end

    if not handcuffedPlayers[target] then
        TriggerClientEvent("QBCore:Notify", src, "La persona no está esposada", "error")
        return
    end

    if playersWithBag[target] then
        TriggerClientEvent("sh-radiogang:interaccion:quitarBolsaCabeza", target)
        playersWithBag[target] = nil
        TriggerClientEvent("QBCore:Notify", src, "Bolsa removida", "primary")
    else
        TriggerClientEvent("sh-radiogang:interaccion:colocarBolsaCabeza", target)
        playersWithBag[target] = true
        TriggerClientEvent("QBCore:Notify", src, "Bolsa colocada", "success")
    end
end)

-- Endpoint simple para HTTP requests (solo para evitar errores)
Citizen.CreateThread(function()
    -- Crear un endpoint HTTP simple que no haga nada pero evite errores
    exports('executeInteraction', function(req, res)
        local data = json.decode(req.body)
        if data and data.action then
            TriggerEvent("sh-radiogang:interaccion:nuiInteract", data.action, source)
            res.send(json.encode({success = true}))
        else
            res.send(json.encode({error = "Acción no válida"}))
        end
    end)
end)

