Config = {}
Config.Locale = 'es'

-- Ítem requerido para abrir la radio
Config.RequiredItem = "radio"

-- Tecla para abrir la radio (F6)
Config.OpenKey = 167

-- Frecuencias para Gangs (20 por gang)
Config.GangFrequencies = {
    ballas = {
        start = 6000,
        name = "Ballas"
    },
    vagos = {
        start = 6020,
        name = "Vagos"
    },
    families = {
        start = 6040,
        name = "Families"
    },
    cartel = {
        start = 6060,
        name = "Cartel"
    },
    lostmc = {
        start = 6080,
        name = "Lost MC"
    }
}

-- Nombres de las frecuencias
Config.FrequencyNames = {
    "Frecuencia A",
    "Frecuencia B",
    "Frecuencia C",
    "Frecuencia D",
    "Frecuencia E",
    "Frecuencia F",
    "Frecuencia G",
    "Frecuencia H",
  --  "Frecuencia I",
  --  "Frecuencia J",
  --  "Frecuencia K",
  --  "Frecuencia L",
  --  "Frecuencia M",
  --  "Frecuencia N",
   -- "Frecuencia O",
  --  "Frecuencia P",
  --  "Frecuencia Q",
  --  "Frecuencia R",
   -- "Frecuencia S",
   -- "Frecuencia T"
}

-- Gang Menu Config
Config.GangMenu = {
    enabled = true,
    locations = {
        ballas = {
            vector3(-1031.8, -3318.65, 12.94),  -- Ejemplo para Ballas
        },
        vagos = {
            vector3(334.92, -2037.87, 21.09),  -- Ejemplo para Vagos
        },
        families = {
            vector3(-1027.5, -3315.88, 12.94) -- Ejemplo para Families
        },
        cartel = {
            vector3(1392.67, 1141.71, 114.33), -- Ejemplo para Cartel
        },
        lostmc = {
            vector3(986.24, -92.64, 74.85),    -- Ejemplo para Lost MC
        }
    },
    useTarget = true, -- Si usas qb-target
    menuKey = 38, -- Tecla E
    menuText = "Presiona [E] para abrir el menú de gang"
}

-- Configuración de almacenes
Config.Stashes = {
    boss = {
        maxweight = 4000000,  -- 4000 kg
        slots = 40
    },
    common = {
        maxweight = 2000000,  -- 2000 kg
        slots = 40
    }
}

-- Configuración mínima y máxima de cargas
Config.MinCharges = 1  -- Mínimo de cargas requeridas
Config.MaxCharges = 10 -- Máximo de cargas permitidas

-- Permitir uso sin cargas (para testing)
Config.AllowUsageWithNoCharges = false

-- Cooldowns / timings
Config.JammerBlipInterval = 500 -- ms, envío de posiciones
Config.JammerDurationMax = 60 * 60 * 1000 -- 1 hora máx por seguridad (ms)

-- Props y modelos que vamos a usar
Config.JammerModel = "m23_2_prop_m32_jammer_01a"
Config.JammerObjectHash = nil -- se rellenará con GetHashKey en client

-- Configuración de destrucción del jammer por disparos
Config.JammerHealth = 10 -- Cantidad de disparos necesarios para destruir el jammer

-- Modelo de NPC para misión
Config.NPCModel = "s_m_y_swat_01" -- Cambiado a SWAT más agresivo

-- Arma para NPCs de misión
Config.NPCWeapon = "WEAPON_COMBATMG" -- Ametralladora

-- Modelo del trailer para la misión
Config.TrailerModel = "tr_prop_tr_cabine_01a"

-- Ubicaciones para la misión (puedes mover/editar)
Config.MissionStart = vector4(-1017.49, -3341.56, 13.94, 48.68)
Config.MissionTarget = vector3(-1110.72, -3240.92, 13.95)
Config.NPCPositions = {
    vector4(-1118.36, -3337.89, 13.95, 324.63),
    vector4(-1121.17, -3324.11, 13.95, 300.91),
    vector4(-1127.41, -3312.04, 13.95, 291.17),
    vector4(-1125.00, -3318.00, 13.95, 291.17),
    vector4(-1117.1, -3288.32, 13.96, 180.42)
}

-- Ubicación del trailer (cabaña del trailer) - CORREGIDA para que quede en el suelo
Config.TrailerSpawn = vector4(-1152.34, -3308.24, 13.15, 235.27) -- Z reducida en 1 metro

-- Restricción: quién puede iniciar misión (chequeado con IsGangMember)
Config.RequireGang = true

-- Configuración de detección de policías
Config.JammerBlipInterval = 1000 -- ms (1 segundo)
Config.PoliceDetectionRange = 100.0 -- Rango en metros para detectar policías (opcional)

-- Nombre de la tabla SQL (puedes cambiar)
Config.SQLTable = "gang_charges"

-- Configuración de efectos especiales al destruir el jammer
Config.JammerDestroyEffects = {
    {
        dict = "core", 
        effect = "ent_sht_electrical_box"
    }
    -- Puedes agregar más efectos aquí
}

-- Configuración de efectos cuando recibe daño (pero no se destruye)
Config.JammerDamageEffects = {
    {
        dict = "core",
        effect = "ent_amb_elec_crackle_sp"
    }
}

-- Tiempo que dura el efecto (en milisegundos)
Config.JammerEffectDuration = 1500

-- Referencias para Gangs
Config.ReferenceIcons = {
    { id = 143, name = "Miembro de banda" },
    { id = 52, name = "Robo tienda" },
    { id = 61, name = "Hospital" },
    { id = 110, name = "Tiroteo" },
    { id = 496, name = "Venta Sustancias" },
    { id = 188, name = "Secuestrando" },
    { id = 455, name = "Robo de Yate" },
    { id = 523, name = "Robo Auto Deportivo" },
    { id = 545, name = "Carrera" },
    { id = 674, name = "Relevante" },
    { id = 617, name = "Robo Joyeria" },
    { id = 502, name = "Número 1" },
    { id = 503, name = "Número 2" },
    { id = 504, name = "Número 3" },
    { id = 374, name = "Robo de banco" },
    { id = 72, name = "Grafitis" },
    { id = 679, name = "Casino" }
}

Config.ReferenceColors = {
    { id = 0, name = "Blanco" },
    { id = 1, name = "Rojo" },
    { id = 2, name = "Verde" },
    { id = 3, name = "Azul" },
    { id = 5, name = "Amarillo" },
    { id = 7, name = "Violeta" },
    { id = 11, name = "Verde Suave" },
    { id = 17, name = "Anaranjado" },
    { id = 23, name = "Rosa Suave" },
    { id = 28, name = "Amarillo Oscuro" },
    { id = 29, name = "Azul Oscuro" },
    { id = 40, name = "Gris Oscuro" }
}

-- Sistema de referencias por gang
Config.ReferencesEnabled = true

