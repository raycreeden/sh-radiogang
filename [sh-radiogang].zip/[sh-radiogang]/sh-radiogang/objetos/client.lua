-- objetos/client.lua
local QBCore = exports['qb-core']:GetCoreObject()
Config = Config or {} -- usar el config global

local myGang = nil
local localJammers = {} -- [netId] = {obj = entity, ownerGang = "ballas", ownerSrc = src, blips = {}, active = false, health = Config.JammerHealth}

-- Variables para la misión
local missionBlip = nil
local missionNPCs = {}
local missionStarted = false
local missionCompleted = false
local missionTrailer = nil
local missionTargetBlip = nil
local missionCheckThread = nil
local npcCheckThread = nil

-- Variables para sistema de cargas
local currentCharges = 0
local maxCharges = Config.MaxCharges

-- inicializar hash
CreateThread(function()
    Config.JammerObjectHash = GetHashKey(Config.JammerModel)
    Config.TrailerObjectHash = GetHashKey(Config.TrailerModel)
end)

-- helper getPlayerGang local
local function UpdateMyGang()
    local pd = QBCore.Functions.GetPlayerData()
    myGang = pd and pd.gang and pd.gang.name or nil
end

CreateThread(function()
    while true do
        UpdateMyGang()
        Wait(5000)
    end
end)

-- Función para obtener cargas iniciales (FALTA ESTA FUNCIÓN)
function GetInitialCharges()
    if myGang then
        TriggerServerEvent("sh-radiogang:objetos:getCharges")
    end
end

-- Agregar esta línea para cargar las cargas al iniciar el script
CreateThread(function()
    Wait(5000) -- Esperar a que el player esté listo
    UpdateMyGang()
    if myGang then
        GetInitialCharges()
    end
end)

-- Reemplazar el evento de actualización de cargas con este código mejorado
RegisterNetEvent("sh-radiogang:objetos:updateCharges", function(gang, count)
    UpdateMyGang()
    if myGang == gang then
        currentCharges = count
        print("[Cargas] Cargas actualizadas: " .. currentCharges .. "/" .. maxCharges)
        
        -- Enviar a la UI inmediatamente
        SendNUIMessage({
            type = "updateChargesUI",
            count = currentCharges,
            max = maxCharges
        })
        
        -- DEBUG: Forzar actualización en consola
        print("[DEBUG] UI actualizada - Cargas: " .. currentCharges .. "/" .. maxCharges)
    end
end)

-- Agregar esta función para forzar actualización al abrir el NUI
RegisterNUICallback("getCharges", function(_, cb)
    if myGang then
        TriggerServerEvent("sh-radiogang:objetos:getCharges")
    end
    cb("ok")
end)

-- Actualizar cargas cuando cambia la gang
CreateThread(function()
    while true do
        local oldGang = myGang
        UpdateMyGang()
        
        if myGang ~= oldGang and myGang then
            GetInitialCharges()
        end
        
        Wait(10000)
    end
end)

-- NUI callback invokeJammer
RegisterNUICallback("invokeJammer", function(_, cb)
    -- pedir al server intentar usar carga y spawn
    local ped = PlayerPedId()
    local spawn = GetOffsetFromEntityInWorldCoords(ped, 0.0, 1.0, 0.0)
    TriggerServerEvent("sh-radiogang:objetos:tryUseCharge", NetworkGetNetworkIdFromEntity(PlayerPedId()), spawn)
    cb("ok")
end)

-- Spawn prop en client (lo provoca el server con evento)
RegisterNetEvent("sh-radiogang:objetos:spawnJammer", function(spawnCoords)
    local ped = PlayerPedId()
    local spawnPos = spawnCoords or (GetOffsetFromEntityInWorldCoords(ped, 0.0, 1.0, 0.0))

    RequestModel(Config.JammerObjectHash)
    local tries = 0
    while not HasModelLoaded(Config.JammerObjectHash) and tries < 50 do
        RequestModel(Config.JammerObjectHash)
        Wait(50)
        tries = tries + 1
    end

    if not HasModelLoaded(Config.JammerObjectHash) then
        QBCore.Functions.Notify("Error cargando modelo del dispositivo", "error")
        return
    end

    -- ✅ Crear el objeto y luego colocarlo en el suelo
    local obj = CreateObject(Config.JammerObjectHash, spawnPos.x, spawnPos.y, spawnPos.z, true, true, true)
    SetEntityAsMissionEntity(obj, true, true)
    
    -- ✅ Colocar perfectamente en el suelo
    PlaceObjectOnGroundProperly(obj)
    
    local netId = NetworkGetNetworkIdFromEntity(obj)
    -- registro local (INACTIVO inicialmente)
    localJammers[netId] = {
        obj = obj, 
        ownerGang = myGang, 
        ownerSrc = GetPlayerServerId(PlayerId()), 
        blips = {},
        active = false,  -- IMPORTANTE: Inicialmente inactivo
        health = Config.JammerHealth,  -- Salud inicial del jammer
        lastHealth = 1000
    }

    -- registrar en server para que inicie envíos de policía
    TriggerServerEvent("sh-radiogang:objetos:registerActiveJammer", netId, myGang)

    -- registrar target con qb-target para el objeto (Activar/Eliminar)
    Citizen.CreateThread(function()
        Wait(1000) -- Esperar un poco para que el objeto se estabilice
        
        if exports['qb-target'] then
            exports['qb-target']:AddTargetEntity(obj, {
                options = {
                    {
                        type = "client",
                        event = "sh-radiogang:objetos:clientActivateJammer",
                        icon = "fa-solid fa-bolt",
                        label = "Activar",
                        netId = netId, -- Pasar netId directamente
                        canInteract = function(entity, distance, data)
                            UpdateMyGang()
                            local info = localJammers[data.netId]
                            return info and info.ownerGang == myGang and distance < 2.5 and not info.active
                        end
                    },
                    {
                        type = "client",
                        event = "sh-radiogang:objetos:clientDestroyJammer",
                        icon = "fa-solid fa-trash",
                        label = "Eliminar",
                        netId = netId, -- Pasar netId directamente
                        canInteract = function(entity, distance, data)
                            UpdateMyGang()
                            local info = localJammers[data.netId]
                            return info and info.ownerGang == myGang and distance < 2.5
                        end
                    }
                },
                distance = 2.5
            })
        end
    end)

-- Sistema de daño por disparos al jammer - CORREGIDO (funciona con cualquier persona)
CreateThread(function()
    while localJammers[netId] and DoesEntityExist(obj) do
        local currentHealth = GetEntityHealth(obj)
        local jammer = localJammers[netId]
        
        if jammer.lastHealth and currentHealth < jammer.lastHealth then
            -- El objeto recibió daño (de cualquier fuente)
            local damage = jammer.lastHealth - currentHealth
            if damage > 10 then -- Solo contar daño significativo
                jammer.health = jammer.health - 1
                SetEntityHealth(obj, 1000) -- Resetear salud
                
                if jammer.health <= 0 then
                    -- Jammer destruido
                    QBCore.Functions.Notify("¡Dispositivo destruido!", "error")
                    
                    -- ✅ EFECTO ESPECIAL AL DESTRUIRSE - PRIMERO EL EFECTO
                    local jammerCoords = GetEntityCoords(obj)
                    TriggerServerEvent("sh-radiogang:objetos:playDestroyEffect", jammerCoords)
                    
                    -- Esperar un poco para que se vea el efecto antes de eliminar
                    Wait(500)
                    
                    -- Limpiar blips
                    for _, b in ipairs(jammer.blips or {}) do
                        if DoesBlipExist(b) then
                            RemoveBlip(b)
                        end
                    end
                    
                    -- Eliminar entidad
                    if DoesEntityExist(jammer.obj) then
                        DeleteEntity(jammer.obj)
                    end
                    
                    -- Notificar servidor
                    TriggerServerEvent("sh-radiogang:objetos:unregisterJammer", netId)
                    localJammers[netId] = nil
                    break
                else
                    QBCore.Functions.Notify("Dispositivo dañado: " .. jammer.health .. "/" .. Config.JammerHealth, "warning")
                    StartScreenEffect("ExplosionJosh3", 100, false)
                    
                    -- ✅ EFECTO DE CHISPAS CUANDO RECIBE DAÑO (opcional)
                    local jammerCoords = GetEntityCoords(obj)
                    TriggerServerEvent("sh-radiogang:objetos:playDamageEffect", jammerCoords)
                end
            end
        end
        
        jammer.lastHealth = GetEntityHealth(obj)
        Wait(500)
    end
end)

QBCore.Functions.Notify("Dispositivo desplegado. Usa [E] para activarlo.", "success")
print("[Jammer] Dispositivo creado - NetId: " .. netId .. " - Gang: " .. (myGang or "none"))
end)

-- ✅ EVENTO PARA EFECTO DE DAÑO (cuando recibe daño pero no se destruye)
RegisterNetEvent("sh-radiogang:objetos:clientPlayDamageEffect", function(coords)
    -- Efecto más suave para cuando recibe daño
    if Config.JammerDamageEffects then
        for _, effect in ipairs(Config.JammerDamageEffects) do
            if effect.dict and effect.effect then
                if not HasNamedPtfxAssetLoaded(effect.dict) then
                    RequestNamedPtfxAsset(effect.dict)
                    while not HasNamedPtfxAssetLoaded(effect.dict) do
                        Wait(10)
                    end
                end
                
                UseParticleFxAssetNextCall(effect.dict)
                StartParticleFxNonLoopedAtCoord(
                    effect.effect,
                    coords.x, coords.y, coords.z + 0.3,
                    0.0, 0.0, 0.0,
                    0.5, -- Escala más pequeña para daño
                    false, false, false, false
                )
            end
        end
    end
end)

-- ✅ EVENTO PARA REPRODUCIR EFECTO ESPECIAL DE DESTRUCCIÓN
RegisterNetEvent("sh-radiogang:objetos:clientPlayDestroyEffect", function(coords)
    print("[Jammer] Reproduciendo efecto de DESTRUCCIÓN en: " .. coords.x .. ", " .. coords.y .. ", " .. coords.z)
    
    -- Cargar y reproducir todos los efectos configurados
    for _, effect in ipairs(Config.JammerDestroyEffects or {}) do
        if effect.dict and effect.effect then
            -- Cargar el dictionary del efecto
            if not HasNamedPtfxAssetLoaded(effect.dict) then
                RequestNamedPtfxAsset(effect.dict)
                local tries = 0
                while not HasNamedPtfxAssetLoaded(effect.dict) and tries < 50 do
                    Wait(10)
                    tries = tries + 1
                end
            end
            
            if HasNamedPtfxAssetLoaded(effect.dict) then
                -- Configurar y reproducir el efecto
                UseParticleFxAssetNextCall(effect.dict)
                StartParticleFxNonLoopedAtCoord(
                    effect.effect,
                    coords.x, coords.y, coords.z + 0.5, -- Un poco más arriba del suelo
                    0.0, 0.0, 0.0,
                    1.0, -- Escala
                    false, false, false, false
                )
                print("[Jammer] Efecto reproducido: " .. effect.effect)
            else
                print("[Jammer] ERROR: No se pudo cargar el dictionary: " .. effect.dict)
            end
        end
    end
    
    -- También reproducir sonido de explosión eléctrica
    PlaySoundFromCoord(-1, "SPARKLES", coords.x, coords.y, coords.z, "GTAO_MAGNETS_FW_MAGNET_LOOP_SOUNDS", true, 10, false)
    
    print("[Jammer] Efecto de destrucción completado")
end)

-- Cliente: activar (ejecuta animación y avisa al server que empiece a mandar coords)
RegisterNetEvent("sh-radiogang:objetos:clientActivateJammer", function(data)
    local netId = data.netId
    print("[Jammer] Intentando activar jammer NetId: " .. netId)
    
    if not localJammers[netId] then
        QBCore.Functions.Notify("Error: Dispositivo no encontrado", "error")
        return
    end
    
    -- Actualizar estado local
    localJammers[netId].active = true
    
    -- Enviar al servidor para activar
    TriggerServerEvent("sh-radiogang:objetos:activateJammerServer", netId)
    QBCore.Functions.Notify("Dispositivo activado. Detectando policías...", "success")
    print("[Jammer] Jammer activado - NetId: " .. netId)
end)

RegisterNetEvent("sh-radiogang:objetos:clientDestroyJammer", function(data)
    local netId = data.netId
    print("[Jammer] Eliminando jammer NetId: " .. netId)
    
    -- Limpiar blips primero
    if localJammers[netId] then
        for _, b in ipairs(localJammers[netId].blips or {}) do
            if DoesBlipExist(b) then
                RemoveBlip(b)
            end
        end
        localJammers[netId].blips = {}
    end
    
    -- Borrar entidad y datos
    if localJammers[netId] and DoesEntityExist(localJammers[netId].obj) then
        DeleteEntity(localJammers[netId].obj)
        print("[Jammer] Entidad eliminada - NetId: " .. netId)
    end
    
    localJammers[netId] = nil
    TriggerServerEvent("sh-radiogang:objetos:unregisterJammer", netId)
    QBCore.Functions.Notify("Dispositivo eliminado.", "primary")
end)

-- Server envía posiciones de policias; cliente recibe y dibuja blips SOLO si pertenece a la misma gang que el jammer
RegisterNetEvent("sh-radiogang:objetos:updateJammerBlips", function(netId, policePositions, jammerGang)
    UpdateMyGang()
    
    -- Verificar si somos de la misma gang y el jammer existe localmente
    if myGang ~= jammerGang then 
        -- Limpiar blips si existen
        if localJammers[netId] then
            for _, b in ipairs(localJammers[netId].blips or {}) do
                if DoesBlipExist(b) then
                    RemoveBlip(b)
                end
            end
            localJammers[netId].blips = {}
        end
        return 
    end

    -- Verificar que el jammer existe y está activo
    if not localJammers[netId] then
        return
    end
    
    if not localJammers[netId].active then
        -- Limpiar blips si no está activo
        for _, b in ipairs(localJammers[netId].blips or {}) do
            if DoesBlipExist(b) then
                RemoveBlip(b)
            end
        end
        localJammers[netId].blips = {}
        return
    end

    -- limpiar blips previos del jammer
    for _, b in ipairs(localJammers[netId].blips or {}) do
        if DoesBlipExist(b) then
            RemoveBlip(b)
        end
    end
    localJammers[netId].blips = {}

    -- crear blips para cada policia
    for i, pos in ipairs(policePositions or {}) do
        local blip = AddBlipForCoord(pos.x, pos.y, pos.z)
        SetBlipSprite(blip, 484) -- icono pedido
        SetBlipColour(blip, 1)
        SetBlipAsShortRange(blip, false)
        SetBlipDisplay(blip, 2) -- Aparece en mapa y minimapa
        SetBlipScale(blip, 0.8) -- Tamaño
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString("Policía Detectado")
        EndTextCommandSetBlipName(blip)
        table.insert(localJammers[netId].blips, blip)
    end
end)

-- ============================
-- SISTEMA DE MISIÓN COMPLETO CORREGIDO
-- ============================

-- Evento que se ejecuta al interactuar con el ped
RegisterNetEvent("sh-radiogang:objetos:startMission", function()
    if missionStarted then
        QBCore.Functions.Notify("Ya tienes una misión en curso.", "error")
        return
    end
    
    missionStarted = true
    missionCompleted = false
    QBCore.Functions.Notify("Has iniciado la misión, dirígete al punto marcado en el mapa.", "primary")

    -- ✅ HACER DESAPARECER EL NPC PARA TODOS
    TriggerServerEvent("sh-radiogang:objetos:hideMissionNPC")

    -- Marcar ruta al punto de misión
    missionBlip = AddBlipForCoord(Config.MissionTarget.x, Config.MissionTarget.y, Config.MissionTarget.z)
    SetBlipSprite(missionBlip, 280)
    SetBlipColour(missionBlip, 5)
    SetBlipRoute(missionBlip, true)
    SetBlipRouteColour(missionBlip, 5)
    SetBlipAsShortRange(missionBlip, false)

    -- Iniciar thread para verificar llegada al punto
    if missionCheckThread then
        Citizen.TerminateThread(missionCheckThread)
    end
    
    missionCheckThread = CreateThread(function()
        while missionStarted and not missionCompleted do
            local playerPed = PlayerPedId()
            local playerCoords = GetEntityCoords(playerPed)
            local targetCoords = vector3(Config.MissionTarget.x, Config.MissionTarget.y, Config.MissionTarget.z)
            local distance = #(playerCoords - targetCoords)

            if distance < 30.0 then -- Rango de activación
                -- Llegó al punto, iniciar siguiente etapa
                QBCore.Functions.Notify("Has llegado al punto. Elimina a los guardias.", "primary")
                StartNPCSpawn()
                break
            end
            
            Wait(1000)
        end
        missionCheckThread = nil
    end)
end)

-- ✅ AGREGAR ESTE EVENTO PARA OCULTAR EL NPC
RegisterNetEvent("sh-radiogang:objetos:clientHideMissionNPC", function()
    -- Buscar y eliminar el NPC de misión
    local pedModel = `cs_bankman`
    local npcCoords = Config.MissionStart
    
    local nearbyPeds = GetGamePool('CPed')
    for _, ped in ipairs(nearbyPeds) do
        if DoesEntityExist(ped) then
            local pedCoords = GetEntityCoords(ped)
            local distance = #(pedCoords - vector3(npcCoords.x, npcCoords.y, npcCoords.z))
            
            if distance < 5.0 then
                local model = GetEntityModel(ped)
                if model == pedModel then
                    -- Eliminar el target primero
                    if exports['qb-target'] then
                        exports['qb-target']:RemoveTargetEntity(ped, "Buscar Dispositivo")
                    end
                    -- Eliminar el ped
                    DeleteEntity(ped)
                    print("[Misión] NPC de misión eliminado")
                    break
                end
            end
        end
    end
end)

-- Función para spawnear NPCs
function StartNPCSpawn()
    -- Limpiar blip de ruta
    if missionBlip then
        RemoveBlip(missionBlip)
        missionBlip = nil
    end

    -- Spawnear NPCs en las posiciones configuradas
    local pedModel = GetHashKey(Config.NPCModel)
    
    RequestModel(pedModel)
    local tries = 0
    while not HasModelLoaded(pedModel) and tries < 50 do
        RequestModel(pedModel)
        Wait(50)
        tries = tries + 1
    end

    if not HasModelLoaded(pedModel) then
        print("[Misión] ERROR: No se pudo cargar el modelo de NPC")
        return
    end

    for i, pos in ipairs(Config.NPCPositions) do
        local npc = CreatePed(4, pedModel, pos.x, pos.y, pos.z, pos.w, true, true)
        if DoesEntityExist(npc) then
            -- Configurar NPC como enemigo agresivo
            SetPedAsEnemy(npc, true)
            SetPedCombatAttributes(npc, 46, true) -- Siempre pelea
            SetPedCombatAttributes(npc, 5, true) -- Puede usar vehículos
            SetPedCombatAbility(npc, 3) -- Habilidad de combate máxima
            SetPedCombatMovement(npc, 3) -- Perseguir agresivamente
            SetPedCombatRange(npc, 3) -- Rango de combate largo
            SetPedAlertness(npc, 3) -- Máxima alerta
            SetPedFleeAttributes(npc, 0, false) -- No huir
            SetPedSeeingRange(npc, 100.0)
            SetPedHearingRange(npc, 100.0)
            
            -- Dar ametralladora
            GiveWeaponToPed(npc, GetHashKey(Config.NPCWeapon), 500, false, true)
            SetPedAccuracy(npc, 80) -- Alta precisión
            SetPedDropsWeaponsWhenDead(npc, false)
            
            -- Task de combate
            TaskCombatPed(npc, PlayerPedId(), 0, 16)
            
            -- Agregar a la tabla
            missionNPCs[#missionNPCs + 1] = npc
        end
    end

    -- Iniciar thread para verificar si todos los NPCs están muertos
    if npcCheckThread then
        Citizen.TerminateThread(npcCheckThread)
    end
    
    npcCheckThread = CreateThread(function()
        while missionStarted and not missionCompleted do
            local allDead = true
            
            for i, npc in ipairs(missionNPCs) do
                if DoesEntityExist(npc) and not IsPedDeadOrDying(npc, true) then
                    allDead = false
                    break
                end
            end

            if allDead and #missionNPCs > 0 then
                -- Todos los NPCs están muertos, misión completada
                missionCompleted = true
                CompleteMission()
                break
            end
            
            Wait(3000)
        end
        npcCheckThread = nil
    end)
end

-- Función para completar la misión
function CompleteMission()
    QBCore.Functions.Notify("¡Misión completada! Busca el trailer para recolectar la carga.", "success")
    
    -- Spawnear el trailer
    CreateMissionTrailer()
    
    -- Resetear variables después de 10 minutos
    SetTimeout(600000, function()
        if missionStarted then
            CleanupMission()
        end
    end)
end

-- Función para crear el trailer de misión
function CreateMissionTrailer()
    local trailerCoords = Config.TrailerSpawn
    
    RequestModel(Config.TrailerObjectHash)
    local tries = 0
    while not HasModelLoaded(Config.TrailerObjectHash) and tries < 50 do
        RequestModel(Config.TrailerObjectHash)
        Wait(50)
        tries = tries + 1
    end

    if not HasModelLoaded(Config.TrailerObjectHash) then
        print("[Misión] ERROR: No se pudo cargar el modelo del trailer")
        return
    end

    -- ✅ Crear el trailer y colocarlo perfectamente en el suelo
    missionTrailer = CreateObject(Config.TrailerObjectHash, trailerCoords.x, trailerCoords.y, trailerCoords.z, true, true, true)
    if DoesEntityExist(missionTrailer) then
        SetEntityAsMissionEntity(missionTrailer, true, true)
        
        -- ✅ Colocar perfectamente en el suelo (igual que el jammer)
        PlaceObjectOnGroundProperly(missionTrailer)
        SetEntityHeading(missionTrailer, trailerCoords.w)
        FreezeEntityPosition(missionTrailer, true)

        -- ✅ Agregar qb-target DIRECTAMENTE en la prop del trailer
        if exports['qb-target'] then
            exports['qb-target']:AddTargetEntity(missionTrailer, {
                options = {
                    {
                        type = "client",
                        event = "sh-radiogang:objetos:collectMissionProp",
                        icon = "fas fa-box",
                        label = "Recolectar Carga",
                        canInteract = function(entity, distance, data)
                            return distance < 2.5
                        end
                    }
                },
                distance = 2.5
            })
        end

        -- Crear blip para el trailer
        missionTargetBlip = AddBlipForCoord(trailerCoords.x, trailerCoords.y, trailerCoords.z)
        SetBlipSprite(missionTargetBlip, 477)
        SetBlipColour(missionTargetBlip, 5)
        SetBlipAsShortRange(missionTargetBlip, true)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString("Carga Disponible")
        EndTextCommandSetBlipName(missionTargetBlip)
        
        print("[Misión] Trailer creado y posicionado correctamente en el suelo")
    else
        print("[Misión] ERROR: No se pudo crear el trailer")
    end
end

-- Evento para recolectar el objeto de misión
RegisterNetEvent("sh-radiogang:objetos:collectMissionProp", function()
    QBCore.Functions.Notify("Has recolectado la carga. +1 Carga para tu gang.", "success")
    
    -- Notificar al servidor para agregar carga
    TriggerServerEvent("sh-radiogang:objetos:addCharge")
    
    -- Limpiar misión
    CleanupMission()
end)

-- Función para limpiar la misión
function CleanupMission()
    -- Terminar threads
    if missionCheckThread then
        Citizen.TerminateThread(missionCheckThread)
        missionCheckThread = nil
    end
    
    if npcCheckThread then
        Citizen.TerminateThread(npcCheckThread)
        npcCheckThread = nil
    end
    
    -- Limpiar NPCs
    for i, npc in ipairs(missionNPCs) do
        if DoesEntityExist(npc) then
            DeleteEntity(npc)
        end
    end
    
    -- Limpiar trailer y su target
    if missionTrailer and DoesEntityExist(missionTrailer) then
        -- Remover target primero
        if exports['qb-target'] then
            exports['qb-target']:RemoveTargetEntity(missionTrailer, "Recolectar Carga")
        end
        DeleteEntity(missionTrailer)
        missionTrailer = nil
    end
    
    -- Limpiar blips
    if missionBlip and DoesBlipExist(missionBlip) then
        RemoveBlip(missionBlip)
        missionBlip = nil
    end
    
    if missionTargetBlip and DoesBlipExist(missionTargetBlip) then
        RemoveBlip(missionTargetBlip)
        missionTargetBlip = nil
    end
    
    -- Resetear variables
    missionNPCs = {}
    missionStarted = false
    missionCompleted = false
    
    print("[Misión] Misión limpiada completamente")
end

-- ============================
-- NPC para iniciar misión gang
-- ============================
CreateThread(function()
    local pedModel = `cs_bankman`
    RequestModel(pedModel)
    while not HasModelLoaded(pedModel) do
        Wait(0)
    end

    local ped = CreatePed(0, pedModel, Config.MissionStart.x, Config.MissionStart.y, Config.MissionStart.z - 1, Config.MissionStart.w, false, true)
    SetEntityInvincible(ped, true)
    SetBlockingOfNonTemporaryEvents(ped, true)
    FreezeEntityPosition(ped, true)

    exports['qb-target']:AddTargetEntity(ped, {
        options = {
            {
                type = "client",
                event = "sh-radiogang:objetos:startMission",
                icon = "fas fa-microchip",
                label = "Buscar Dispositivo",
                canInteract = function(entity, distance, data)
                    local PlayerData = QBCore.Functions.GetPlayerData()
                    return PlayerData.gang and PlayerData.gang.name ~= "none" and distance < 2.0
                end,
            }
        },
        distance = 2.5
    })
end)

-- limpieza de blips en desconexión o eliminación
AddEventHandler('onClientResourceStop', function(resName)
    if resName ~= GetCurrentResourceName() then return end
    -- Limpiar jammers
    for netId, info in pairs(localJammers) do
        for _, b in ipairs(info.blips or {}) do
            if DoesBlipExist(b) then
                RemoveBlip(b)
            end
        end
        if DoesEntityExist(info.obj) then
            DeleteEntity(info.obj)
        end
    end
    -- Limpiar misión
    CleanupMission()
end)