-- objetos/server.lua
local QBCore = exports['qb-core']:GetCoreObject()
local activeJammers = {} -- [netId] = {ownerGang = "ballas", owner = src, active = false}

-- Helper: get gang for player
local function GetPlayerGang(src)
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return nil end
    local g = Player.PlayerData.gang and Player.PlayerData.gang.name or nil
    return g
end

-- SQL helpers
local function AddChargeToGang(gang, amount)
    if not gang then return end
    amount = tonumber(amount) or 1
    local max = Config.MaxCharges or 10
    exports.oxmysql:execute("INSERT INTO "..Config.SQLTable.." (`gang`, `charges`) VALUES (?, ?) ON DUPLICATE KEY UPDATE charges = LEAST(charges + VALUES(charges), ?);", {gang, amount, max})
end

local function UseChargeForGang(gang)
    if not gang then return false end
    local res = exports.oxmysql:scalarSync("SELECT charges FROM "..Config.SQLTable.." WHERE gang = ? LIMIT 1", {gang})
    local current = tonumber(res) or 0
    if current <= 0 then return false end
    exports.oxmysql:execute("UPDATE "..Config.SQLTable.." SET charges = GREATEST(charges - 1, 0) WHERE gang = ?", {gang})
    return true
end

local function GetCharges(gang, cb)
    exports.oxmysql:scalar("SELECT charges FROM "..Config.SQLTable.." WHERE gang = ? LIMIT 1", {gang}, function(result)
        cb(tonumber(result) or 0)
    end)
end

-- Evento para obtener cargas
RegisterNetEvent("sh-radiogang:objetos:getCharges", function()
    local src = source
    local gang = GetPlayerGang(src)
    if not gang then return end
    
    GetCharges(gang, function(count)
        TriggerClientEvent("sh-radiogang:objetos:updateCharges", src, gang, count)
        print("[Server] Enviando cargas a " .. src .. " - Gang: " .. gang .. " - Cargas: " .. count)
    end)
end)

-- Evento para agregar carga (por completar misión)
RegisterNetEvent("sh-radiogang:objetos:addCharge", function()
    local src = source
    local gang = GetPlayerGang(src)
    if not gang then
        TriggerClientEvent("QBCore:Notify", src, "No perteneces a ninguna gang.", "error")
        return
    end
    
    -- Obtener cargas actuales
    local res = exports.oxmysql:scalarSync("SELECT charges FROM "..Config.SQLTable.." WHERE gang = ? LIMIT 1", {gang})
    local currentCharges = tonumber(res) or 0
    
    print("[Server] Cargas actuales para " .. gang .. ": " .. currentCharges)
    
    -- Verificar máximo
    if currentCharges >= Config.MaxCharges then
        TriggerClientEvent("QBCore:Notify", src, "Tu gang ya tiene el máximo de cargas ("..Config.MaxCharges..").", "error")
        return
    end
    
    -- Agregar carga
    AddChargeToGang(gang, 1)
    
    -- Calcular nuevo total
    local newCount = currentCharges + 1
    
    print("[Server] Nuevo total de cargas para " .. gang .. ": " .. newCount)
    
    -- Enviar actualización a TODOS los miembros de la gang
    for _, playerId in ipairs(GetPlayers()) do
        local player = QBCore.Functions.GetPlayer(tonumber(playerId))
        if player and player.PlayerData.gang and player.PlayerData.gang.name == gang then
            TriggerClientEvent("sh-radiogang:objetos:updateCharges", tonumber(playerId), gang, newCount)
            print("[Server] Actualizando cargas para jugador " .. playerId .. ": " .. newCount)
        end
    end
    
    TriggerClientEvent("QBCore:Notify", src, "¡+1 Carga para tu gang! Total: " .. newCount .. "/" .. Config.MaxCharges, "success")
end)

-- Evento: intentar usar una carga (invocar jammer)
RegisterNetEvent("sh-radiogang:objetos:tryUseCharge", function(netId, spawnCoords)
    local src = source
    local gang = GetPlayerGang(src)
    if not gang then
        TriggerClientEvent("QBCore:Notify", src, "No perteneces a ninguna gang.", "error")
        return
    end

    -- ✅ CORREGIDO: Verificar cargas según configuración
    if not Config.AllowUsageWithNoCharges then
        -- Obtener cargas actuales
        local res = exports.oxmysql:scalarSync("SELECT charges FROM "..Config.SQLTable.." WHERE gang = ? LIMIT 1", {gang})
        local currentCharges = tonumber(res) or 0
        
        -- Verificar si tiene el mínimo requerido
        if currentCharges < Config.MinCharges then
            TriggerClientEvent("QBCore:Notify", src, "No tienes suficientes cargas. Mínimo requerido: " .. Config.MinCharges, "error")
            return
        end
        
        -- Usar una carga
        local used = UseChargeForGang(gang)
        if not used then
            TriggerClientEvent("QBCore:Notify", src, "Error al usar carga.", "error")
            return
        end
    else
        -- Modo testing: solo notificar
        local res = exports.oxmysql:scalarSync("SELECT charges FROM "..Config.SQLTable.." WHERE gang = ? LIMIT 1", {gang})
        local currentCharges = tonumber(res) or 0
        
        if currentCharges < Config.MinCharges then
            TriggerClientEvent("QBCore:Notify", src, "Modo testing: Cargas insuficientes ("..currentCharges.."/"..Config.MinCharges..") pero permitido", "primary")
        else
            -- Decrementar si hay cargas disponibles
            UseChargeForGang(gang)
        end
    end

    TriggerClientEvent("sh-radiogang:objetos:spawnJammer", src, spawnCoords)

    -- Actualizar cargas después de usar una
    GetCharges(gang, function(count)
        TriggerClientEvent("sh-radiogang:objetos:updateCharges", -1, gang, count)
    end)
end)

-- Registro cuando el jammer se coloca
RegisterNetEvent("sh-radiogang:objetos:registerActiveJammer", function(netId, gang)
    local src = source
    activeJammers[netId] = {
        owner = src, 
        ownerGang = gang, 
        created = os.time(), 
        active = false  -- Inicialmente inactivo
    }
    print("[Jammer Server] Jammer registrado - NetId: " .. netId .. " - Gang: " .. gang .. " - Estado: INACTIVO")
end)

-- Evento para activar el jammer
RegisterNetEvent("sh-radiogang:objetos:activateJammerServer", function(netId)
    print("[Jammer Server] Recibida activación para NetId: " .. netId)
    
    if activeJammers[netId] then
        activeJammers[netId].active = true
        print("[Jammer Server] Jammer ACTIVADO - NetId: " .. netId .. " - Gang: " .. activeJammers[netId].ownerGang)
        
        -- Notificar al cliente que se activó correctamente
        TriggerClientEvent("QBCore:Notify", activeJammers[netId].owner, "Dispositivo activado correctamente", "success")
    else
        print("[Jammer Server] ERROR: Jammer no encontrado para activación - NetId: " .. netId)
    end
end)

RegisterNetEvent("sh-radiogang:objetos:unregisterJammer", function(netId)
    print("[Jammer Server] Eliminando jammer - NetId: " .. netId)
    activeJammers[netId] = nil
end)

-- Server tick: enviar posiciones de policías
CreateThread(function()
    while true do
        Wait(Config.JammerBlipInterval or 1000)
        
        if next(activeJammers) == nil then
            -- nada activo
        else
            -- Enviar solo a jammers ACTIVOS
            for netId, info in pairs(activeJammers) do
                if info.active then
                    -- recolectar policías EN RANGO para cada jammer
                    local policePositions = {}
                    local jammerCoords = GetEntityCoords(GetPlayerPed(info.owner))
                    
                    for _, playerId in ipairs(GetPlayers()) do
                        local p = tonumber(playerId)
                        local pl = QBCore.Functions.GetPlayer(p)
                        if pl and pl.PlayerData.job and pl.PlayerData.job.name == "police" and pl.PlayerData.job.onduty then
                            local ped = GetPlayerPed(p)
                            if DoesEntityExist(ped) then
                                local coords = GetEntityCoords(ped)
                                -- ✅ FILTRAR POR DISTANCIA
                                local distance = #(jammerCoords - coords)
                                if distance <= (Config.PoliceDetectionRange or 100.0) then
                                    table.insert(policePositions, {x = coords.x, y = coords.y, z = coords.z})
                                end
                            end
                        end
                    end

                    -- DEBUG
                    if #policePositions > 0 then
                        print("[Jammer Server] Enviando " .. #policePositions .. " policías EN RANGO a jammer " .. netId)
                    end
                    
                    TriggerClientEvent("sh-radiogang:objetos:updateJammerBlips", -1, netId, policePositions, info.ownerGang)
                end
            end
        end
    end
end)

-- ✅ EVENTO PARA OCULTAR NPC PARA TODOS
RegisterNetEvent("sh-radiogang:objetos:hideMissionNPC", function()
    TriggerClientEvent("sh-radiogang:objetos:clientHideMissionNPC", -1) -- -1 = todos los jugadores
    print("[Misión Server] Ocultando NPC de misión para todos los jugadores")
end)

-- ✅ EVENTO PARA REPRODUCIR EFECTO DE DESTRUCCIÓN PARA TODOS LOS JUGADORES
RegisterNetEvent("sh-radiogang:objetos:playDestroyEffect", function(coords)
    TriggerClientEvent("sh-radiogang:objetos:clientPlayDestroyEffect", -1, coords)
    print("[Jammer Server] Reproduciendo efecto de DESTRUCCIÓN para todos los jugadores en: " .. coords.x .. ", " .. coords.y .. ", " .. coords.z)
end)

-- ✅ EVENTO PARA EFECTO DE DAÑO
RegisterNetEvent("sh-radiogang:objetos:playDamageEffect", function(coords)
    TriggerClientEvent("sh-radiogang:objetos:clientPlayDamageEffect", -1, coords)
    print("[Jammer Server] Reproduciendo efecto de DAÑO para todos los jugadores en: " .. coords.x .. ", " .. coords.y .. ", " .. coords.z)
end)